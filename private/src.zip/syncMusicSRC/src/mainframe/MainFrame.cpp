//
//  MainFrame.cpp
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//
#include "audio_player.h"
//native scope variables
extern GlbPara glbpara;
extern PrjPara prjpara;
extern PlayerPara playerpara;

SNDFILE *infile;
SNDFILE *click_infile;
SF_INFO	sfinfo;
SF_INFO click_sfinfo;
PaStream *stream;
PaError err;

extern LinearFunction cur_linear, update_linear, new_linear;
extern Audio_buffer buffer;
extern Rock callbackRock;
extern Network network;
extern RefMedMap rmm;
extern PerfRefMap prm;
extern RefMedMap *final_rmm;
extern Phase_vocoder* pv;

PerfRefMap player_prm;
/*
float test_incount = 0;
float test_last_incount;
extern float test_cur_beat;
float test_last_beat = 0;
extern float test_cur_time;
float test_last_time = 0;
long test_sample_count = 0;
long test_sample_lenth = 0;
float hop_size = 0;
float test_hop_size = 0;
LinearFunction test;*/



MainFrame :: MainFrame(const wxString & title)
:wxFrame(NULL , -1 , title, wxDefaultPosition, wxSize(780,410)) {
    err_timer = new wxTimer(this, ID_ERR_TIMER);
    play_timer = new wxTimer(this, ID_PLAY_TIMER);
    time_sync = new wxTimer(this, ID_SYNC_TIMER);
    recv_message = new wxTimer(this, ID_RECV_TIMER);
    tempo_timer = new wxTimer(this, ID_TEMPO_TIMER);
    //front interface initialization
    wxPanel *pan = new wxPanel(this,wxID_ANY);
    
    //first line--------------------------------------
    
    play = new wxButton(pan , ID_PLAY , "PLAY");
    pause_resume = new wxButton(pan , ID_PAUSE , "PAUSE");
    stop = new wxButton(pan , ID_STOP , "STOP");
    
    wxStaticText *label_project = new wxStaticText(pan, wxID_ANY, "Project");
    combo_project = new wxComboBox(pan, ID_PROJECT);
    wxStaticText *label_ID = new wxStaticText(pan, wxID_ANY, "ID");
    combo_audio_id = new wxComboBox(pan, ID_AUD_ID);
    
    //second line--------------------------------------
    
    wxStaticText *label_start_beats = new wxStaticText(pan, wxID_ANY, "Start Beats");
    wxtxt_start_beats = new wxTextCtrl(pan, ID_START_BEAT, "0");
    
    wxStaticText *label_end_beats = new wxStaticText(pan, wxID_ANY, "End Beats");
    wxtxt_end_beats = new wxTextCtrl(pan, ID_END_BEAT, "9999");
    check_arrangement = new wxCheckBox(pan, ID_ARRANGEMENT, "Arrangement");
    wxStaticText *label_argnmt_name = new wxStaticText(pan, wxID_ANY, "Name: ");
    arngmt_name = new wxStaticText(pan, wxID_ANY, "None");
    
    //third line--------------------------------------
    
    speed_bar = new wxSlider(pan , ID_SPEED , 200 , 0 , 1000 , wxDefaultPosition
                             , wxSize(480 , -1) , wxSL_HORIZONTAL);
    //forth line--------------------------------------
    
    wxStaticText *label_tempo_scale = new wxStaticText(pan, wxID_ANY, "Tempo Scale:");
    tempo_scale_value = new wxStaticText(pan, wxID_ANY, "1");
    wxStaticText *label_tempo = new wxStaticText(pan, wxID_ANY, "Tempo:");
    tempo_value = new wxStaticText(pan, wxID_ANY, "1234567890");
    wxStaticText *label_tempo_unit = new wxStaticText(pan, wxID_ANY, "bpm");
    
    wxStaticText *label_mode = new wxStaticText(pan, wxID_ANY, "Mode");
    wxString mode_list[4];
    mode_list[0] = "Tempo Track";
    mode_list[1] = "Override";
    mode_list[2] = "Conductor";
    mode_list[3] = "Label";
    combo_mode = new wxComboBox(pan, ID_MODE, "Tempo Track", wxDefaultPosition
                                , wxDefaultSize, 4, mode_list, wxCB_READONLY);
    check_rcd = new wxCheckBox(pan, ID_CHECK_RCD, "record");
    //fifth line--------------------------------------
    
    volume_bar = new wxSlider(pan , ID_VOLUME , 20 , 0 , 100 , wxDefaultPosition
                              , wxSize(480, -1) , wxSL_HORIZONTAL);
    //sixth line--------------------------------------
    
    wxStaticText *label_volume = new wxStaticText(pan, wxID_ANY, "Volume:");
    volume_value = new wxStaticText(pan, wxID_ANY, "123");
    wxStaticText *label_volume_unit = new wxStaticText(pan, wxID_ANY, "dB");
    btn_test = new wxButton(pan, ID_TEST, "TEST");
    
    //seventh line----------------------------------------------------------------
    wxStaticText *label_first_beats = new wxStaticText(pan, wxID_ANY, "First Beat:");
    wxtxt_first_beat = new wxTextCtrl(pan, ID_FIRST_BEAT, "0");
    wxStaticText *label_beat_step = new wxStaticText(pan, wxID_ANY, "Beat Step:");
    wxtxt_beat_step = new wxTextCtrl(pan, ID_BEAT_STEP, "2");
    wxStaticText *label_beat_offset = new wxStaticText(pan, wxID_ANY, "Beat Offset:");
    wxtxt_beat_offset = new wxTextCtrl(pan, ID_BEAT_OFFSET, "0");
    wxStaticText *label_offset_unit = new wxStaticText(pan, wxID_ANY, "ms");
    
    
    //eighth line----------------------------------------------------------------
    wxStaticText *label_tap = new wxStaticText(pan, wxID_ANY, "Space Tap:");
    wxtxt_space_tap = new wxTextCtrl(pan, ID_SPACE_TAP, "");
    
    wxBoxSizer *firstline_sizer = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *secondline_sizer = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *thirdline_sizer = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *forthline_sizer = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *fifthline_sizer = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *sixthline_sizer = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *sevenline_sizer = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *eightline_sizer = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *whole_sizer = new wxBoxSizer(wxVERTICAL);
    
    firstline_sizer->Add(play , wxSizerFlags(0).Align(1).Border(wxRIGHT,25));
    firstline_sizer->Add(pause_resume , wxSizerFlags(0).Align(1).Border(wxRIGHT,25));
    firstline_sizer->Add(stop , wxSizerFlags(0).Align(1).Border(wxRIGHT,25));
    firstline_sizer->Add(label_project , wxSizerFlags(0).Align(1).Border(wxALL,5));
    firstline_sizer->Add(combo_project , wxSizerFlags(0).Align(1).Border(wxALL,5));
    firstline_sizer->Add(label_ID , wxSizerFlags(0).Align(1).Border(wxALL,5));
    firstline_sizer->Add(combo_audio_id , wxSizerFlags(0).Align(1).Border(wxALL,5));
    
    secondline_sizer->Add(label_start_beats , wxSizerFlags(0).Align(1).Border(wxALL,5));
    secondline_sizer->Add(wxtxt_start_beats , wxSizerFlags(0).Align(1).Border(wxRIGHT,15));
    secondline_sizer->Add(label_end_beats , wxSizerFlags(0).Align(1).Border(wxALL,5));
    secondline_sizer->Add(wxtxt_end_beats , wxSizerFlags(0).Align(1).Border(wxRIGHT,15));
    secondline_sizer->Add(check_arrangement , wxSizerFlags(0).Align(1).Border(wxALL,5));
    secondline_sizer->Add(label_argnmt_name , wxSizerFlags(0).Align(1).Border(wxALL,5));
    secondline_sizer->Add(arngmt_name , wxSizerFlags(0).Align(1).Border(wxALL,5));
    
    thirdline_sizer->Add(speed_bar , wxSizerFlags(0).Align(1).Border(wxALL,5));
    
    forthline_sizer->Add(label_tempo_scale , wxSizerFlags(0).Align(1).Border(wxALL,5));
    forthline_sizer->Add(tempo_scale_value , wxSizerFlags(0).Align(1).Border(wxRIGHT,15));
    forthline_sizer->Add(label_tempo , wxSizerFlags(0).Align(1).Border(wxALL,5));
    forthline_sizer->Add(tempo_value , wxSizerFlags(0).Align(1).Border(wxRIGHT,15));
    forthline_sizer->Add(label_tempo_unit , wxSizerFlags(0).Align(1).Border(wxALL,5));
    forthline_sizer->Add(label_mode , wxSizerFlags(0).Align(1).Border(wxALL,5));
    forthline_sizer->Add(combo_mode , wxSizerFlags(0).Align(1).Border(wxALL,5));
    forthline_sizer->Add(check_rcd , wxSizerFlags(0).Align(1).Border(wxALL,5));
    
    fifthline_sizer->Add(volume_bar , wxSizerFlags(0).Align(1).Border(wxALL,5));
    
    sixthline_sizer->Add(label_volume , wxSizerFlags(0).Align(1).Border(wxALL,5));
    sixthline_sizer->Add(volume_value , wxSizerFlags(0).Align(1).Border(wxALL,5));
    sixthline_sizer->Add(label_volume_unit , wxSizerFlags(0).Align(1).Border(wxALL,5));
    sixthline_sizer->Add(btn_test , wxSizerFlags(0).Align(1).Border(wxALL,5));
    
    sevenline_sizer->Add(label_first_beats, wxSizerFlags(0).Align(1).Border(wxALL,5));
    sevenline_sizer->Add(wxtxt_first_beat, wxSizerFlags(0).Align(1).Border(wxALL,5));
    sevenline_sizer->Add(label_beat_step, wxSizerFlags(0).Align(1).Border(wxALL,5));
    sevenline_sizer->Add(wxtxt_beat_step, wxSizerFlags(0).Align(1).Border(wxALL,5));
    sevenline_sizer->Add(label_beat_offset, wxSizerFlags(0).Align(1).Border(wxALL,5));
    sevenline_sizer->Add(wxtxt_beat_offset, wxSizerFlags(0).Align(1).Border(wxALL,5));
    sevenline_sizer->Add(label_offset_unit, wxSizerFlags(0).Align(1).Border(wxALL,5));
    
    eightline_sizer->Add(label_tap, wxSizerFlags(0).Align(1).Border(wxALL,5));
    eightline_sizer->Add(wxtxt_space_tap, wxSizerFlags(0).Align(1).Border(wxALL,5));
    
    whole_sizer->Add(firstline_sizer , wxSizerFlags(0).Center().Border(wxTOP, 15));
    whole_sizer->Add(secondline_sizer , wxSizerFlags(0).Center().Border(wxTOP, 15));
    whole_sizer->Add(thirdline_sizer , wxSizerFlags(0).Center().Border(wxTOP, 15));
    whole_sizer->Add(forthline_sizer , wxSizerFlags(0).Center().Border(wxTOP, 15));
    whole_sizer->Add(fifthline_sizer , wxSizerFlags(0).Center().Border(wxTOP, 15));
    whole_sizer->Add(sixthline_sizer , wxSizerFlags(0).Center().Border(wxTOP, 15));
    whole_sizer->Add(sevenline_sizer , wxSizerFlags(0).Center().Border(wxTOP, 15));
    whole_sizer->Add(eightline_sizer , wxSizerFlags(0).Center().Border(wxTOP, 15));
    pan->SetSizer(whole_sizer);
    
    //menu interface initialization
    wx_menubar = new wxMenuBar;
    wx_menu_file = new wxMenu;
    wx_menu_view = new wxMenu;
    wx_menu_fft = new wxMenu;
    
    wx_menu_file->Append(ID_MENU_NETWORK , "Network\tAlt+N");
    wx_menu_file->Append(ID_MENU_IMPORT , "Import\tAlt+I");
    wx_menu_file->Append(ID_MENU_SET_PATH , "Set Music Path\tAlt+P");
    wx_menu_file->Append(ID_MENU_DEVICE , "Audio Devices\tAlt+D");
    wx_menu_file->Append(ID_MENU_SAVE_LABEL , "Save Labels\tAlt+S");
    
    wx_menu_view->Append(ID_MENU_ARRANGEMENT , "Arrangement\tAlt+A");
    wx_menu_view->Append(ID_MENU_MEDIA_MAP , "Media Map\tAlt+M");
    
    wx_menu_fft->Append(ID_MENU_FFT_256 , "256");
    wx_menu_fft->Append(ID_MENU_FFT_512 , "512");
    wx_menu_fft->Append(ID_MENU_FFT_1024 , "1024");
    wx_menu_fft->Append(ID_MENU_FFT_2048 , "2048");
    wx_menu_fft->Append(ID_MENU_FFT_4096 , "4096");
    wx_menu_fft->Append(ID_MENU_FFT_8192 , "8192");
    wx_menu_fft->Append(ID_MENU_FFT_FOURTH , "hopsize: 1/4 fft");
    wx_menu_fft->Append(ID_MENU_FFT_EIGHTH , "hopsize: 1/8 fft");
    wx_menu_fft->Append(ID_MENU_FFT_SIXTEENTH , "hopsize: 1/16 fft");
    
    wx_menubar->Append(wx_menu_file, "File");
    wx_menubar->Append(wx_menu_view, "View");
    wx_menubar->Append(wx_menu_fft, "FFT");
    SetMenuBar(wx_menubar);
    
    Connect(ID_MENU_NETWORK, wxEVT_COMMAND_MENU_SELECTED
            ,wxCommandEventHandler(MainFrame::OnNetwork));
    Connect(ID_MENU_IMPORT, wxEVT_COMMAND_MENU_SELECTED
            ,wxCommandEventHandler(MainFrame::OnImport));
    Connect(ID_MENU_SET_PATH, wxEVT_COMMAND_MENU_SELECTED
            ,wxCommandEventHandler(MainFrame::OnSetPath));
    Connect(ID_MENU_DEVICE, wxEVT_COMMAND_MENU_SELECTED
            ,wxCommandEventHandler(MainFrame::OnSelectDevice));
    /*Connect(ID_MENU_DEVICE, wxEVT_COMMAND_MENU_SELECTED
     ,wxCommandEventHandler(MainFrame::OnDevices));
     Connect(ID_MENU_ARRANGEMENT, wxEVT_COMMAND_MENU_SELECTED
     ,wxCommandEventHandler(MainFrame::OnArrangement));*/
     Connect(ID_MENU_MEDIA_MAP, wxEVT_COMMAND_MENU_SELECTED
     ,wxCommandEventHandler(MainFrame::OnMediaMap));
    Connect(ID_MENU_FFT_256,ID_MENU_FFT_SIXTEENTH, wxEVT_COMMAND_MENU_SELECTED
            ,wxCommandEventHandler(MainFrame::OnFFT));
    Connect(ID_MENU_SAVE_LABEL, wxEVT_COMMAND_MENU_SELECTED
            ,wxCommandEventHandler(MainFrame::OnSaveLabel));
    Connect(ID_CHECK_RCD, wxEVT_COMMAND_CHECKBOX_CLICKED
            , wxCommandEventHandler(MainFrame::OnUpdateRcdFlag));
    Connect(ID_START_BEAT,ID_END_BEAT, wxEVT_TEXT
            , wxTextEventHandler(MainFrame::OnChangePrefs));
    Connect(ID_FIRST_BEAT,ID_BEAT_OFFSET, wxEVT_TEXT
            , wxTextEventHandler(MainFrame::OnChangePrefs));
    Connect(ID_SPACE_TAP, wxEVT_TEXT
            , wxTextEventHandler(MainFrame::OnRecording));
    Connect(ID_ARRANGEMENT, wxEVT_COMMAND_CHECKBOX_CLICKED
            , wxCommandEventHandler(MainFrame::OnChangePrefs));
    Connect(ID_MODE, wxEVT_COMMAND_COMBOBOX_SELECTED
            , wxCommandEventHandler(MainFrame::OnChangePrefs));
    Connect(ID_PROJECT, wxEVT_COMMAND_COMBOBOX_SELECTED
            ,wxCommandEventHandler(MainFrame::OnSelectProject));
    Connect(ID_PROJECT, wxEVT_COMMAND_COMBOBOX_DROPDOWN
            ,wxCommandEventHandler(MainFrame::OnDropdownPrj));
    Connect(ID_AUD_ID, wxEVT_COMMAND_COMBOBOX_SELECTED
            ,wxCommandEventHandler(MainFrame::OnSelectId));
    Connect(ID_AUD_ID, wxEVT_COMMAND_COMBOBOX_DROPDOWN
            ,wxCommandEventHandler(MainFrame::OnDropdownId));
    Connect(ID_PLAY , wxEVT_COMMAND_BUTTON_CLICKED
            , wxCommandEventHandler(MainFrame :: OnPlay));
    Connect(ID_SPEED , wxEVT_COMMAND_SLIDER_UPDATED
            , wxCommandEventHandler(MainFrame :: OnChangeSpeed));
    Connect(ID_PAUSE, wxEVT_COMMAND_BUTTON_CLICKED
            , wxCommandEventHandler(MainFrame::OnPause));
    Connect(ID_STOP, wxEVT_COMMAND_BUTTON_CLICKED
            , wxCommandEventHandler(MainFrame::OnStop));
    Connect(ID_TEST, wxEVT_COMMAND_BUTTON_CLICKED
            , wxCommandEventHandler(MainFrame::OnTest));
    
    Connect(ID_ERR_TIMER , wxEVT_TIMER, wxTimerEventHandler(MainFrame :: OnErrTimer));
    Connect(ID_PLAY_TIMER, wxEVT_TIMER, wxTimerEventHandler(MainFrame :: OnPlayTimer));
    Connect(ID_SYNC_TIMER, wxEVT_TIMER, wxTimerEventHandler(MainFrame :: OnSyncTimer));
    Connect(ID_RECV_TIMER, wxEVT_TIMER, wxTimerEventHandler(MainFrame :: OnRecvTimer));
    Connect(ID_TEMPO_TIMER, wxEVT_TIMER, wxTimerEventHandler(MainFrame :: OnUpdateTempo));
    
    err_timer->Start(ERROR_INTERVAL);
    
    LabelWidgetsDisable();
    
    readGlbPref();
    NetworkDialog net_dialog;
    int flag = net_dialog.ShowModal();
    if (flag == HOSTIP_LOCALHOST) {
        prjpara.mode = MODE_CONDUCTOR;
    } else if (flag == HOSTIP_NONE) {
        prjpara.mode = MODE_TEMPO_TRACK;
    }
    recv_message->Start(10);
    time_sync->Start(3000);
    showOnCanvas();
}

void MainFrame :: OnPlay(wxCommandEvent & WXUNUSED(event)) {
    if (prjpara.mode == MODE_CONDUCTOR) {
        glbpara.err_reminder = ERR_INVALID_PLAY;
    } else {
        if (prjpara.mode == MODE_LABEL) {
            if (prjpara.lab_file.empty() && prjpara.tapping_timing.empty()) {
                glbpara.rcd = true;
            } else {
                glbpara.rcd = check_rcd->GetValue();
            }
            if (glbpara.rcd) {
                prjpara.tapping_num = 0;
                prjpara.tapping_timing.clear();
                
                wxtxt_start_beats->Disable();
                wxtxt_end_beats->Disable();
                wxtxt_space_tap->Enable();
                wxtxt_space_tap->SetFocus();
                speed_bar->Disable();
            }
            if (prjpara.click_file.empty()) {
                glbpara.err_reminder = ERR_SND_CLICK_NONEXIST;
                return ;
            }
        }
        Preparation();
    }
}

void MainFrame :: Preparation() {
    resetMusicPara();
    if (prjpara.mode != MODE_LABEL) {
        final_rmm = &rmm;
    }
    //test
//    static int wgqi = 0;
//    wgqi++;
//    if (wgqi == 2) {
//        wgqi = wgqi;
//    }
/*    prm.Reset();
    prm.SetAllocate(3);
    int i;
    prm.ref_beat[0] = 0;
    prm.ref_beat[1] = 8;
    prm.ref_beat[2] = 0;
    for (i = 0; i < 3 ; i++) {
        prm.duration[i] = 8;
 }*/
    
    if (!(glbpara.music_path && glbpara.prj_name && glbpara.aud_name)) {
        glbpara.err_reminder = ERR_NON_PATH;
        return ;
    }
    
    //initializing
    sfinfo.format = 0;
    const char *ch_aud = prjpara.wav_file.c_str();
    
    err = Pa_Initialize();
    if (err != paNoError) {
        glbpara.err_reminder = ERR_PA_INIT;
        return ;
    }
    
    if (!(infile = sf_open (ch_aud, SFM_READ, &sfinfo))) {
        glbpara.err_reminder = ERR_SND_OPEN;
        Pa_Terminate();
        return  ;
    }
    
    pv = (Phase_vocoder *)malloc(sizeof(Phase_vocoder) * sfinfo.channels);
    callbackRock.setChannels(sfinfo.channels);
    for (int i = 0; i < sfinfo.channels; i++) {
        pv[i] = pv_create2(malloc, free, test_callback, &callbackRock);//multi-channels
        pv_set_fftsize(pv[i], prjpara.pv_fft_size);//multi-channels
        pv_initialize(pv[i]);//multi-channels
    }
    
    glbpara.framePerBuffer = BLOCK_SIZE;//multi-channels
    playerpara.play_data_each = (float **)(malloc(sizeof(float*) * sfinfo.channels));
    if (prjpara.mode != MODE_CONDUCTOR) {
        float size = 2 + (float)prjpara.pv_fft_size * 3 / 4 / glbpara.framePerBuffer;
        if (size != (int)size) {
            size++;
        }
        playerpara.sgmtMap.allocate((int)size);
    }
    
    if (prjpara.mode == MODE_CONDUCTOR) {
        glbpara.audio_state = AUDIO_IDLE;
    } else {
        glbpara.audio_state = AUDIO_PLAY;
        if (prjpara.mode != MODE_LABEL) {
            if (!wxtxt_start_beats->GetValue().ToDouble(&prjpara.start_beat)) {
                glbpara.err_reminder = ERR_STARTBEAT_FORMAT;
                return ;
            }
        } else {
            prjpara.start_beat = 0.0f;
        }
    }
        
    if (prjpara.arrag == 1 && !prm.IsNull() && prjpara.mode != MODE_LABEL) {
        final_rmm = prm.SetPMM(rmm);//multi-channels!
    }
    
    // initialize playing paras
    if (final_rmm == NULL || final_rmm->IsNull()) {//without arrangement and media map
        if (final_rmm == NULL) {
            playerpara.first_frame = 0;
        } else {
            playerpara.first_frame = beatsToTime(prjpara.start_beat) * sfinfo.samplerate;//multi-channels
        }
        if (prjpara.mode != MODE_LABEL) {
            if (!wxtxt_end_beats->GetValue().ToDouble(&prjpara.end_beat)) {
                glbpara.err_reminder = ERR_ENDBEAT_FORMAT;
                return ;
            }
        } else {
            prjpara.end_beat = 9999;
        }
        
        if (prjpara.end_beat == 9999) {
            playerpara.last_sample = sfinfo.frames;
        } else {
            playerpara.last_sample = beatsToTime(prjpara.end_beat) * sfinfo.samplerate;//multi-channels
        }
        playerpara.frame_lenth = playerpara.last_sample - playerpara.first_frame;
        printf("BIG:%f\n",(float)playerpara.frame_lenth/sfinfo.samplerate);//test
    } else {
        playerpara.first_frame = beatsToTime(final_rmm->Ref2Media(prjpara.start_beat)) * sfinfo.samplerate;//multi-channels
        if (prjpara.mode != MODE_CONDUCTOR) {
            if (!wxtxt_end_beats->GetValue().ToDouble(&prjpara.end_beat)) {
                glbpara.err_reminder = ERR_ENDBEAT_FORMAT;
                return ;
            }
            playerpara.frame_lenth = CalculateFrameLen(*final_rmm, prjpara.start_beat, prjpara.end_beat);//multi-channels!
            if (playerpara.frame_lenth < 0) {
                glbpara.err_reminder = ERR_ENDBEAT_LESS_THAN_STARTBEAT;
                return ;
            }
        } else {
            playerpara.frame_lenth = CalculateFrameLen(*final_rmm, prjpara.start_beat);//multi-channels!
            //sample_lenth = CalculateSampLen(start_beat, end_beat);
            //add logic here?
            if (playerpara.frame_lenth < 0) {
                glbpara.err_reminder = ERR_ENDBEAT_LESS_THAN_STARTBEAT;
                return ;
            }
        }
        final_rmm->cur_read_ref_beat = prjpara.start_beat;
        final_rmm->cur_read_ref_index = final_rmm->GetIndexOfRef(prjpara.start_beat);//multi-channels!
        
        printf("RMMTOTAL:%lf\n",final_rmm->total_time);//test
        printf("BIG:%f\n",(float)playerpara.frame_lenth/sfinfo.samplerate);//test
        printf("\nFirstSam:%ld StartBeat:%lf Media:%lf Time:%lf\n",playerpara.first_frame,prjpara.start_beat,final_rmm->Ref2Media(prjpara.start_beat),beatsToTime(final_rmm->Ref2Media(prjpara.start_beat)));
        
    }
    sf_seek(infile ,(long)(playerpara.first_frame) ,SEEK_SET);//multi-channels
    
    //device processing
    const PaDeviceInfo *deviceInfo;
    bool isExist = false;
    if (!glbpara.DeviceName.empty()) {
        int numDevices;
        numDevices = Pa_GetDeviceCount();
        if( numDevices < 0 )
        {
            printf( "ERROR: Pa_GetDeviceCount returned 0x%x\n", numDevices );
            Pa_Terminate();
            return ;
        }
        for(int i=0; i<numDevices; i++ ) {
            deviceInfo = Pa_GetDeviceInfo( i );
            if (deviceInfo->maxOutputChannels > 0 && glbpara.DeviceName.compare(deviceInfo->name) == 0) {
                isExist = true;
                glbpara.outputPara.device = i;
                glbpara.outputPara.channelCount = deviceInfo->maxOutputChannels;
                glbpara.outputPara.sampleFormat = paFloat32;
                glbpara.outputPara.suggestedLatency = 0; /* ignored by Pa_IsFormatSupported() */
                glbpara.outputPara.hostApiSpecificStreamInfo = NULL;
                if (sfinfo.channels > glbpara.outputPara.channelCount) {
                    glbpara.err_reminder = ERR_CHANNEL;
                    sf_close(infile);
                    Pa_Terminate();
                    return ;
                }
                glbpara.outputPara.channelCount = sfinfo.channels;
                break;
            }
        }
    }
    if (!isExist){
        int index = Pa_GetDefaultOutputDevice();
        deviceInfo = Pa_GetDeviceInfo( index );
        if (sfinfo.channels > deviceInfo->maxOutputChannels){
            glbpara.err_reminder = ERR_CHANNEL;
            sf_close(infile);
            Pa_Terminate();
            return ;
        }
    }
    
    //adjust buffer size and start reading data
    if (!buffer.isValid()) {
        prjpara.read_per_time = (glbpara.read_per_time / sfinfo.channels) * sfinfo.channels;
        buffer.Initialize(prjpara.read_per_time);
    }
    float *buf = buffer.get_read_ptr();
    if (final_rmm == NULL) {
        playerpara.readcount = sf_read_float(infile, buf, prjpara.read_per_time * 2);
    } else {
        playerpara.readcount = ReadBuf(buf, prjpara.read_per_time * 2, *final_rmm);//multi-channels
    }
    if (playerpara.readcount != prjpara.read_per_time * 2) {//multi-channels
        if (playerpara.readcount == 0) {
            glbpara.err_reminder = ERR_EMPTY_FILE;
            return ;
        } else {
            playerpara.audio_file_has_data = false;
        }
    }
    //start playing
    if (!isExist) {
        err = Pa_OpenDefaultStream(&stream, 0, sfinfo.channels, paFloat32, sfinfo.samplerate
                                   , glbpara.framePerBuffer, playCallback, NULL);//multi-channels
    } else {
        err = Pa_OpenStream(&stream, NULL, &glbpara.outputPara, sfinfo.samplerate, glbpara.framePerBuffer,
                            paClipOff, playCallback, NULL);
    }
    if (err != paNoError) {
        glbpara.err_reminder = ERR_PA_OPEN;
        Pa_Terminate();
        sf_close(infile);
        return ;
    }
    err = Pa_StartStream( stream );
    if (err != paNoError) {
        err = Pa_CloseStream( stream );
        Pa_Terminate();
        glbpara.err_reminder = ERR_PA_START;
        sf_close(infile);
        return ;
    }
    
    //periodically reading data from file
    play_timer->Start(READ_CHECK_INTERVAL);
    if (prjpara.mode == MODE_TEMPO_TRACK) {
        tempo_timer->Start(TEMPO_UPDATE_INTERVAL);
    }
}

LinearFunction test;//test

void MainFrame :: OnPlayTimer(wxTimerEvent & WXUNUSED(event)) {
    if (!playerpara.end_flag) {
        float *buff = buffer.ready_for_more();
        if (buff && playerpara.audio_file_has_data) {
            std::cout << "reading more audio data" << std::endl;
            if (final_rmm == NULL) {
                playerpara.readcount = sf_read_float(infile, buff, prjpara.read_per_time);
            } else {
                playerpara.readcount = ReadBuf(buff, prjpara.read_per_time, *final_rmm);//multi-channels
            }
            if (playerpara.readcount != prjpara.read_per_time) {
                playerpara.audio_file_has_data = false;
                std::cout << "reading finished with readcount " << playerpara.readcount << std::endl;
            }
            buffer.write_completed();
        }
        if (!test.isEqualTo(cur_linear)) {
            double x,y,z;
            cur_linear.Get(x, y, z);
            printf("\nCurLinear Change: %lf, %lf, %lf\n", x, y, z);
            test.SetLinear(cur_linear);
        }
    } else {
        err = Pa_StopStream( stream );
        if ( err != paNoError ) {
            sf_close(infile);
            glbpara.err_reminder = ERR_PA_STOP;
            Pa_CloseStream(stream);
            Pa_Terminate();
            return ;
        }
        err = Pa_CloseStream( stream );
        if ( err != paNoError ) {
            sf_close(infile);
            glbpara.err_reminder = ERR_PA_CLOSE;
            Pa_Terminate();
            return ;
        }
        for (int i = 0; i < sfinfo.channels; i++) {
            pv_end(&pv[i]);
        }
        if (pv) {
            free(pv);
            pv = NULL;
        }
        
        if (prjpara.mode == MODE_LABEL && glbpara.audio_state != AUDIO_STOP) {
            check_rcd->Enable();
            if (glbpara.rcd) {
                if(prjpara.label_start_time != NULL) {
                    delete[] prjpara.label_start_time;
                    prjpara.label_start_time = NULL;
                }
                if(prjpara.label_stop_time != NULL) {
                    delete[] prjpara.label_stop_time;
                    prjpara.label_stop_time = NULL;
                }
                if(prjpara.label_index_beats != NULL) {
                    delete[] prjpara.label_index_beats;
                    prjpara.label_index_beats = NULL;
                }
                
                prjpara.label_length = prjpara.tapping_num;
                prjpara.label_start_time = new float[prjpara.tapping_num];
                prjpara.label_stop_time = new float[prjpara.tapping_num];
                prjpara.label_index_beats = new float[prjpara.tapping_num];
                
                for (int i = 0 ; i < prjpara.tapping_num; i++) {
                    prjpara.label_start_time[i] = prjpara.tapping_timing[i];
                    prjpara.label_stop_time[i] = prjpara.tapping_timing[i];
                    prjpara.label_index_beats[i] = i * prjpara.beat_step + prjpara.first_beat;
                }
                prjpara.stableTempo = false;
            }
        }
        
        Pa_Terminate();
        sf_close(infile);
        if (prjpara.mode == MODE_LABEL && glbpara.rcd) {
            wxtxt_space_tap->Disable();
            wxtxt_start_beats->Enable();
            wxtxt_end_beats->Enable();
            speed_bar->Enable();
        }
        
        glbpara.err_reminder = FINISH;
        glbpara.audio_state = AUDIO_STOP;
        play_timer->Stop();
        if (prjpara.mode == MODE_TEMPO_TRACK) {
            tempo_timer->Stop();
        }
        playerpara.originCurTempo = 0;
    }
    
    /*double tx,ty,ts;
    double x,y,s;//test
    cur_linear.Get(x, y, s);
    test.Get(tx, ty, ts);
    if (x != tx || y != ty || s!= ts) {
        printf("CurX:%lf, CurY:%lf, CurZ:%lf\n", x, y, s);
        test.SetLinear(cur_linear);
    }
    if (test_cur_beat != test_last_beat && test_cur_time != test_last_time ) {
        test_last_beat = test_cur_beat;
        test_last_time = test_cur_time;
        printf("CurTime:%lf, CurBeat: %lf\n", test_cur_time, test_cur_beat);
    }
    if(test_incount != test_last_incount) {
        printf("Incount:%f\n",test_incount);
        test_last_incount = test_incount;
    }
    printf("SampleCount!!:%ld\n",buffer.get_sample_count());
    printf("TTTTTT:%d\n",audio_state);
    if(sample_lenth != test_sample_lenth) {
        test_sample_lenth = sample_lenth;
        printf("TestSample:%ld\n",test_sample_lenth);
    }*///test
}

void MainFrame:: OnSelectDevice(wxCommandEvent & WXUNUSED(event)) {
    DevicesList myDevices;
    myDevices.ShowModal();
}

void MainFrame :: OnSetPath(wxCommandEvent & WXUNUSED(event)) {
    SetPathDialog dialog;
    if (dialog.ShowModal() == SUCCESSFUL) {
        if (glbpara.project_list.size() == 1) {//if there is only one proj, choose it automatically
            AutoChoose();
        }
    }
}

void MainFrame::OnNetwork(wxCommandEvent & WXUNUSED(event)) {
    NetworkDialog net_dialog;
    net_dialog.ShowModal();
}

void MainFrame::OnImport(wxCommandEvent & WXUNUSED(event)) {
    if (!glbpara.music_path) {//cannot import without setting music path
        wxMessageDialog error(NULL, "Must Set Music Path First", "Error", wxOK);
        error.ShowModal();
        return ;
    }//add after
    ImportDialog import_dialog;
    if (import_dialog.ShowModal() == SUCCESSFUL) {
        resetPrjPara();
        if (!initPrj()) {
            wxMessageDialog err(NULL, "Cannot Initialize Project. Try import again!"
                                ,"Error",wxOK);
            err.ShowModal();
            return ;
        }
        showOnCanvas();
        combo_project->SetValue(glbpara.prj_name);
        combo_audio_id->SetValue(glbpara.aud_name);
    }
}

void MainFrame::OnMediaMap(wxCommandEvent & WXUNUSED(event)) {
    if (glbpara.music_path && glbpara.prj_name && glbpara.aud_name) {
        MediaMap dialog;
        if (dialog.ShowModal() == SUCCESSFUL) {
            rmm.Reset();
            ReadMapping(prjpara.rmm_file);
        }
    } else {
        wxMessageDialog err(NULL,"Haven't set all the paths yet!","Error",wxOK);
        err.ShowModal();
    }
}

void MainFrame::OnChangeSpeed(wxCommandEvent & WXUNUSED(event)) {
    float temp_ratio = (float)speed_bar->GetValue() / 200;
    if (temp_ratio == 0.00f) {
        wxMessageDialog zero_alert(NULL,"Cannot give a speed value of 0!"
                                   , "Speed Value Invalid!",wxOK);
        speed_bar->SetValue(200);
        temp_ratio = 1.0f;
        zero_alert.ShowModal();
    }
    prjpara.tempo_scale = temp_ratio;
    prjpara.tempo = playerpara.originCurTempo * temp_ratio;
    tempo_scale_value->SetLabel(wxString::Format("%.2f", prjpara.tempo_scale));
    tempo_value->SetLabel(wxString::Format("%.2f", prjpara.tempo));
    if (!prjpara.pref_file.empty()) {
        prefsWrite(prjpara.pref_file.c_str());
    }
    Refresh();
}

void MainFrame::OnFFT(wxCommandEvent &event) {
    switch (event.GetId()) {
        case ID_MENU_FFT_256:
            prjpara.pv_fft_size = 256;
            break;
        case ID_MENU_FFT_512:
            prjpara.pv_fft_size = 512;
            break;
        case ID_MENU_FFT_1024:
            prjpara.pv_fft_size = 1024;
            break;
        case ID_MENU_FFT_2048:
            prjpara.pv_fft_size = 2048;
            break;
        case ID_MENU_FFT_4096:
            prjpara.pv_fft_size = 4096;
            break;
        case ID_MENU_FFT_8192:
            prjpara.pv_fft_size = 8192;
            break;
        case ID_MENU_FFT_FOURTH:
            prjpara.pv_hop_size = prjpara.pv_fft_size / 4;
            break;
        case ID_MENU_FFT_EIGHTH:
            prjpara.pv_hop_size = prjpara.pv_fft_size / 8;
            break;
        case ID_MENU_FFT_SIXTEENTH:
            prjpara.pv_hop_size = prjpara.pv_fft_size / 16;
            break;
    }
    if (!prjpara.pref_file.empty()) {
        prefsWrite(prjpara.pref_file.c_str());
    }
}

void MainFrame::OnPause(wxCommandEvent & WXUNUSED(event)) {
    if (pause_resume->GetLabel().IsSameAs("PAUSE")) {
        if (glbpara.audio_state == AUDIO_PLAY) {
            glbpara.audio_state = AUDIO_IDLE;
            pause_resume->SetLabel("RESUME");
        }
    } else if (pause_resume->GetLabel().IsSameAs("RESUME")) {
        if (glbpara.audio_state == AUDIO_IDLE) {
            glbpara.audio_state = AUDIO_PLAY;
        }
        pause_resume->SetLabel("PAUSE");
    } else {
        wxMessageDialog err(NULL, "Invalid pause_resume button!", "Button Error", wxOK);
        err.ShowModal();
    }
}

void MainFrame::OnStop(wxCommandEvent & WXUNUSED(event)) {
    if (glbpara.audio_state != AUDIO_STOP) {
        glbpara.audio_state = AUDIO_STOP;
    } else {
        glbpara.err_reminder = ERR_INVALID_STOP;
    }
    
    if (prjpara.mode == MODE_LABEL && glbpara.rcd) {
        prjpara.tapping_timing.clear();
        prjpara.tapping_num = 0;
    }
    
    wxtxt_space_tap->Disable();
}

void MainFrame::OnDropdownPrj(wxCommandEvent & WXUNUSED(event)) {
    int i;
    long len = glbpara.project_list.size();
    combo_project->Clear();
    for (i = 0; i < len ; i++) {
        combo_project->Append(glbpara.project_list[i]);
    }
}

void MainFrame::OnSelectProject(wxCommandEvent & WXUNUSED(event)) {
    if ( glbpara.prj_name ) {
        free(glbpara.prj_name);
        glbpara.prj_name = NULL;
    }
    glbpara.prj_name = wxString2char( combo_project->GetStringSelection() );
    combo_project->SetValue(glbpara.prj_name);
    glbPrefWrite(getFullGlbPref());
    std::string audio_id_path = (std::string)(glbpara.music_path) + "/" + glbpara.prj_name;
    if (!updateDropdownItems(audio_id_path, &glbpara.id_list, "audio-")) {
        free(glbpara.prj_name);
        glbpara.prj_name = NULL;
    }
    if (glbpara.id_list.size() == 1) {
        combo_audio_id->SetValue(glbpara.id_list[0].c_str());
        if (glbpara.aud_name) {
            free(glbpara.aud_name);
            glbpara.aud_name = NULL;
        }
        
        resetPrjPara();
        glbpara.aud_name = str2char(glbpara.id_list[0]);
        combo_audio_id->SetValue(glbpara.aud_name);
        glbPrefWrite(getFullGlbPref());
        
        if (!initPrj()) {
            wxMessageDialog err(NULL, "Cannot Initialize Project!","Error",wxOK);
            err.ShowModal();
            return ;
        }
        showOnCanvas();
    }
}

void MainFrame::OnDropdownId(wxCommandEvent & WXUNUSED(event)) {
    int i;
    long len = glbpara.id_list.size();
    combo_audio_id->Clear();
    for (i = 0; i < len ; i++) {
        combo_audio_id->Append(glbpara.id_list[i]);
    }
}

void MainFrame::OnSelectId(wxCommandEvent & WXUNUSED(event)) {
    // a new project has been selected
    // here do some reset stuff and initialization
    if (glbpara.aud_name) {
        free(glbpara.aud_name);
        glbpara.aud_name = NULL;
    }
    resetPrjPara();
    glbpara.aud_name = wxString2char(combo_audio_id->GetStringSelection());
    glbPrefWrite(getFullGlbPref());
    if (!initPrj()) {
        wxMessageDialog err(NULL, "Cannot Initialize Project!","Error",wxOK);
        err.ShowModal();
        return ;
    }
    if (prjpara.mode == MODE_LABEL) {
        LabelWidgetsEnable();
        if (prjpara.lab_file.empty()) {
            glbpara.rcd = true;
            check_rcd->SetValue(true);
            check_rcd->Disable();
        }
    } else {
        LabelWidgetsDisable();
    }
    showOnCanvas();
}

void MainFrame::OnSaveLabel(wxCommandEvent & WXUNUSED(event)) {
    std::ofstream label_track_file;
    std::string label_path = (std::string)(glbpara.music_path) + "/" + glbpara.prj_name +
                             "/" + glbpara.aud_name + "/label_track.txt";
    label_track_file.open(label_path.c_str());
    
    if (label_track_file.is_open()) {
        if (prjpara.tapping_timing.empty()) {
            glbpara.err_reminder = ERR_LABEL_UNFINISHED;
        } else {
            int size = prjpara.label_length;
            for (int i = 0; i < size; i++) {
                std::ostringstream sstream;
                float beat = i * prjpara.beat_step + prjpara.first_beat;
                sstream << prjpara.label_start_time[i] << " " << prjpara.label_stop_time[i] << " \"" << beat << "\"";
                label_track_file << sstream.str() << std::endl;
            }
        }
    } else {
        glbpara.err_reminder = ERR_PREF_NEXIST;
    }
    prjpara.lab_file = label_path;
    label_track_file.close();
}

void MainFrame::OnUpdateRcdFlag(wxCommandEvent & WXUNUSED(event)) {
    glbpara.rcd = check_rcd->GetValue();
}

void MainFrame::OnRecording(wxCommandEvent & WXUNUSED(event)) {
    if (wxtxt_space_tap->GetValue()[0] == ' ') {
        wxtxt_space_tap->Clear();
        std::ostringstream time_stream, beat_stream;
        prjpara.tapping_timing.push_back(playerpara.sgmtMap.getY(playerpara.output_frame_count) / sfinfo.samplerate);
        std::cout << playerpara.output_frame_count << std::endl;
        time_stream << prjpara.tapping_timing[prjpara.tapping_num];
        beat_stream << prjpara.first_beat + prjpara.beat_step * prjpara.tapping_num;
        std::cout << time_stream.str() + " " + time_stream.str() + " \"" + beat_stream.str() + "\"" << std::endl;
        prjpara.tapping_num++;
    }
}

void MainFrame::OnChangePrefs(wxCommandEvent & event) {
    switch (event.GetId()) {
        int temp_mode;
        case ID_START_BEAT:
            wxtxt_start_beats->GetValue().ToDouble(&prjpara.start_beat);
            break;
        case ID_END_BEAT:
            wxtxt_end_beats->GetValue().ToDouble(&prjpara.end_beat);
            break;
        case ID_FIRST_BEAT:
            wxtxt_first_beat->GetValue().ToDouble(&prjpara.first_beat);
            break;
        case ID_BEAT_STEP:
            wxtxt_beat_step->GetValue().ToDouble(&prjpara.beat_step);
            break;
        case ID_BEAT_OFFSET:
            wxtxt_beat_offset->GetValue().ToDouble(&prjpara.beat_offset);
            if (!prjpara.lab_file.empty() && !prjpara.tapping_timing.empty()) {
                int length = prjpara.label_length;
                for (int i = 0; i < length; i++) {
                    prjpara.label_start_time[i] = prjpara.tapping_timing[i] + prjpara.beat_offset / 1000;
                    prjpara.label_stop_time[i] = prjpara.label_start_time[i];
                }
            }
            break;
        case ID_ARRANGEMENT:
            prjpara.arrag = (check_arrangement->GetValue())? 1:0;
            break;
        case ID_MODE:
            temp_mode = combo_mode->GetSelection();
            
            if (temp_mode == MODE_CONDUCTOR) {
                if (glbpara.connect_flag) {
                    prjpara.mode = temp_mode;
                } else {
                    wxMessageDialog err(NULL,"Haven't set up connection yet!", "Connection error",wxOK);
                    err.ShowModal();
                    combo_mode->SetSelection(prjpara.mode);
                }
            } else {
                prjpara.mode = temp_mode;
            }
            
            if (temp_mode == MODE_LABEL) {
                LabelWidgetsEnable();
                if (prjpara.lab_file.empty()) {
                    check_rcd->SetValue(true);
                    check_rcd->Disable();
                    glbpara.rcd = true;
                }
            } else {
                LabelWidgetsDisable();
            }
            break;
        default:
            wxMessageDialog err(NULL, "Err: Other Type Come In", "Error", wxOK);
            err.ShowModal();
            break;
    }
    prjpara.volume = DEFAULT_VOLUME;//add when implemented should change this part
    if (!prjpara.pref_file.empty()) {
        prefsWrite(prjpara.pref_file.c_str());
    } else if (glbpara.aud_name && glbpara.prj_name && glbpara.music_path){
        printf("Err: Trying to save prefs but prefs.txt doesn't exit\n");
    }
}

void MainFrame::speedValueReset() {
    speed_bar->SetValue(200);
    tempo_scale_value->SetLabel(wxString::Format("%.2f", prjpara.tempo_scale));
    Refresh();
}

void MainFrame::OnUpdateTempo(wxTimerEvent &event) {
    tempo_value->SetLabel(wxString::Format("%.2f",prjpara.tempo));
    Refresh();
}

void MainFrame::OnSyncTimer(wxTimerEvent &event) {
    network.timeSync();
}

void MainFrame::OnRecvTimer(wxTimerEvent &event) {
    network.Listener();
}
void MainFrame::OnErrTimer(wxTimerEvent &event) {
    if (glbpara.err_reminder == 0){
        return ;
    } else {
        wxMessageDialog *error;
        switch (glbpara.err_reminder) {
            case ERR_LABEL_UNFINISHED:
                error = new wxMessageDialog(NULL, wxString::Format("Cannot save labels: Labels are empty\n Please switch to label mode and tapping while recording"), "Error", wxOK);
                break;
            case ERR_SAME_DEVICE_NAME:
                error = new wxMessageDialog(NULL, wxString::Format("The last two output devices in the list have the same name, please change pick rule in the source code"), "Error", wxOK);
                break;
            case ERR_CHANNEL:
                error = new wxMessageDialog(NULL, wxString::Format("Device Err:Processing more than device max channels, please change another device or decrease music file channels"), "Error", wxOK);
                break;
            case ERR_EMPTY_FILE:
                error = new wxMessageDialog(NULL, wxString::Format("Err:Input File has no content!"), "Error", wxOK);
                break;
            case ERR_EMPTY_GLB_PREF:
                error = new wxMessageDialog(NULL, wxString::Format("Err:Empty Global APprefs.txt!"), "Error", wxOK);
                break;
            case ERR_NON_PATH:
                error = new wxMessageDialog(NULL, "File Path invalid", "Error", wxOK);
                break;
            case ERR_PREF_NEXIST:
                error = new wxMessageDialog(NULL, "No Pref File Path", "Error", wxOK);
                break;
            case ERR_PA_CLOSE:
                error = new wxMessageDialog(NULL, wxString::Format("Err:Pa_Close_Stream Fail!\nError number: %d \nError message: %s\n", err , Pa_GetErrorText( err )), "PaError!", wxOK);
                break;
            case ERR_PA_INIT:
                error = new wxMessageDialog(NULL,wxString::Format("Err: Pa_Initialize fail \nError number: %d \nError message: %s\n", err , Pa_GetErrorText( err )), "PaError!", wxOK);
                break;
            case ERR_PA_OPEN:
                error = new wxMessageDialog(NULL, wxString::Format("Err:cannot open Pa_stream! \nError number: %d \nError message: %s\n", err , Pa_GetErrorText( err )), "PaError!", wxOK);
                break;
            case ERR_PA_START:
                error = new wxMessageDialog(NULL, wxString::Format("Err:Pa_StartStream Fail!\nError number: %d \nError message: %s\n", err , Pa_GetErrorText( err )), "PaError!", wxOK);
                break;
            case ERR_PA_STOP:
                error = new wxMessageDialog(NULL, wxString::Format("Err:Pa_Stop_Stream Fail!\nError number: %d \nError message: %s\n", err , Pa_GetErrorText( err )), "PaError!", wxOK);
                break;
            case ERR_PV_INVALID_INPUTCOUNT:
                error = new wxMessageDialog(NULL, wxString::Format("Err:Inputcount is less than 0!"), "Error", wxOK);
                break;
            case ERR_SND_OPEN:
                error = new wxMessageDialog(NULL,wxString::Format("SND_OPEN Err: Unable to open file."),"Error", wxOK);
                break;
            case ERR_SND_CLICK_OPEN:
                error = new wxMessageDialog(NULL,wxString::Format("SND_OPEN Err: Unable to open click file."),"Error", wxOK);
                break;
            case ERR_SND_CLICK_NONEXIST:
                error = new wxMessageDialog(NULL,wxString::Format("CLICK Warning: Click file doesn't exist, invalid Playback"),"Error", wxOK);
                break;
            case ERR_WEIRD_AUDIO_STATE:
                error = new wxMessageDialog(NULL, "Invalid Audio State!", "Error", wxOK);
                break;
            case ERR_INVALID_STOP:
                error = new wxMessageDialog(NULL, "Audio has not been played yet!", "Error", wxOK);
                break;
            case ERR_INVALID_PLAY:
                error = new wxMessageDialog(NULL, "Cannot using play button in conductor mode!", "Error", wxOK);
                break;
            case FINISH:
                error = new wxMessageDialog(NULL, "", "Finished!", wxOK);
                break;
        }
        error->ShowModal();
        error->Destroy();
        glbpara.err_reminder = 0;
    }
}
 
void MainFrame::readGlbPref() {
    wxCommandEvent nil;//simulate click
    std::string glb_pref_path = getFullGlbPref();
    int status = getPathStatus(&glb_pref_path);
    if (status == APPATH_FILE) {
        if (!glbPrefRead(glb_pref_path)) {
            OnSetPath(nil);
            OnImport(nil);
        } else {
            if (!updateDropdownItems(glbpara.music_path, &glbpara.project_list)) {
                free(glbpara.music_path);
                glbpara.music_path = NULL;
                OnSetPath(nil);
            }
            if (glbpara.project_list.size() == 1) {//if there is only one proj, choose it automatically
                if (AutoChoose() == 2) {
                    if (glbpara.aud_name) {
                        combo_audio_id->SetValue(glbpara.aud_name);
                        resetPrjPara();
                        if (!initPrj()) {
                            wxMessageDialog err(NULL, "Cannot Initialize Project!","Error",wxOK);
                            err.ShowModal();
                            return ;
                        }
                    }
                }
            } else if (glbpara.prj_name) {
                combo_project->SetValue(glbpara.prj_name);
                std::string audio_id_path = (std::string)(glbpara.music_path) + "/" + glbpara.prj_name;
                if (!updateDropdownItems(audio_id_path, &glbpara.id_list, "audio-")) {
                    free(glbpara.prj_name);
                    glbpara.prj_name = NULL;
                }
                if (glbpara.aud_name) {
                    combo_audio_id->SetValue(glbpara.aud_name);
                    resetPrjPara();
                    if (!initPrj()) {
                        wxMessageDialog err(NULL, "Cannot Initialize Project!","Error",wxOK);
                        err.ShowModal();
                        return ;
                    }
                }
            }
        }
    } else if (status == APPATH_NOT_EXIST) {
        OnSetPath(nil);
        OnImport(nil);
    } else {
        wxMessageDialog err(NULL, "Prefs.txt exists but not a file", "File Error", wxOK);
        err.ShowModal();
    }
    showOnCanvas();
}

void MainFrame::showOnCanvas() {
    wxtxt_start_beats->SetValue(wxString::Format("%.2lf",prjpara.start_beat));
    wxtxt_end_beats->SetValue(wxString::Format("%.2lf",prjpara.end_beat));
    if (prjpara.arrag == 1) {
        check_arrangement->SetValue(true);
    } else {
        check_arrangement->SetValue(false);
    }
    combo_mode->SetSelection(prjpara.mode);
    if (prjpara.tempo_scale == 0) {
        wxMessageDialog err(NULL, "Invalid ratio value from prefs, already chagne it to 1"
                            ,"Error", wxOK);
        err.ShowModal();
        prjpara.tempo_scale = 1;
        prefsWrite(prjpara.pref_file.c_str());
    }
    speed_bar->SetValue(prjpara.tempo_scale * 200);
    tempo_scale_value->SetLabel(wxString::Format("%.2f",prjpara.tempo_scale));
    tempo_value->SetLabel(wxString::Format("%.2f",prjpara.tempo));
    wxtxt_first_beat->SetValue(wxString::Format("%.2lf", prjpara.first_beat));
    wxtxt_beat_step->SetValue(wxString::Format("%.2lf", prjpara.beat_step));
    wxtxt_beat_offset->SetValue(wxString::Format("%.2lf", prjpara.beat_offset));
    Refresh();
    //add set volume here
    
}

int MainFrame::AutoChoose() {
    if (glbpara.prj_name) {
        free(glbpara.prj_name);
        glbpara.prj_name = NULL;
    }
    glbpara.prj_name = str2char(glbpara.project_list[0]);
    combo_project->SetValue(glbpara.prj_name);
    glbPrefWrite(getFullGlbPref());
    std::string audio_id_path = (std::string)(glbpara.music_path) + "/" + glbpara.prj_name;
    if (!updateDropdownItems(audio_id_path, &glbpara.id_list, "audio-")) {
        free(glbpara.prj_name);
        glbpara.prj_name = NULL;
    }
    if (glbpara.id_list.size() == 1) {//only one audio-id, choose it atmtcly
        if (glbpara.aud_name) {
            free(glbpara.aud_name);
            glbpara.aud_name = NULL;
        }
        resetPrjPara();
        glbpara.aud_name = str2char(glbpara.id_list[0]);
        combo_audio_id->SetValue(glbpara.aud_name);
        glbPrefWrite(getFullGlbPref());
        
        if (!initPrj()) {
            wxMessageDialog err(NULL, "Cannot Initialize Project!","Error",wxOK);
            err.ShowModal();
            return 0;
        }
        showOnCanvas();
        return 1;
    } else {
        return 2;
    }
}

void MainFrame::resetMusicPara() {
    if (pv) {
        free(pv);
        pv = NULL;
    }
    playerpara.reset();
    callbackRock.reset();
    if (!rmm.IsNull()) {
        rmm.RestartMusc();
    }
    buffer.resetBuffer();
    final_rmm = NULL;
    
    cur_linear.Reset();
    update_linear.Reset();
    new_linear.Reset();
    
}

void MainFrame::resetPrjPara() {
    rmm.Reset();
    prjpara.reset();
    buffer.resetClass();
}


void MainFrame::SetArngmtName(std::string name) {
    arngmt_name->SetLabel(glbpara.ArngName);
}

void MainFrame::SetArgmtCheck(bool tof) {
    prjpara.arrag = tof? 1:0;
    prefsWrite(prjpara.pref_file.c_str());
    showOnCanvas();
}

void MainFrame::LabelWidgetsDisable() {
    check_rcd->Disable();
    wxtxt_first_beat->Disable();
    wxtxt_beat_step->Disable();
    wxtxt_beat_offset->Disable();
    wxtxt_space_tap->Disable();
}

void MainFrame::LabelWidgetsEnable() {
    check_rcd->Enable();
    wxtxt_first_beat->Enable();
    wxtxt_beat_step->Enable();
    wxtxt_beat_offset->Enable();
}

void MainFrame::OnTest(wxCommandEvent & WXUNUSED(event)) {
    wxtxt_space_tap->SetFocus();
}