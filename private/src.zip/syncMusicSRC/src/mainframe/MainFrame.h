//
//  MainFrame.h
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#ifndef __AudioPlayer__MainFrame__
#define __AudioPlayer__MainFrame__

//main graphic interface about the project
//************************ Description **************************************
//this is a class for displaying all the control components in the project
//***************************************************************************


class MainFrame : public wxFrame{
    //front interface
    //first line
    wxButton *play;
    wxButton *pause_resume;
    wxButton *stop;
    wxComboBox *combo_project;
    wxComboBox *combo_audio_id;
    //second line
    wxTextCtrl *wxtxt_start_beats;
    wxTextCtrl *wxtxt_end_beats;
    wxCheckBox *check_arrangement;
    wxStaticText *arngmt_name;
    //third line
    wxSlider *speed_bar;
    //forth line
    wxStaticText *tempo_scale_value;
    wxStaticText *tempo_value;
    wxComboBox *combo_mode;
    wxCheckBox *check_rcd;
    // check box only under label mode, check if this playback is for
    // recording or for sync and testing
    
    //fifth line
    wxSlider *volume_bar;
    //sixth line
    wxStaticText *volume_value;//add input or output?
    wxButton *btn_test;
    //seventh line
    wxTextCtrl *wxtxt_first_beat;
    wxTextCtrl *wxtxt_beat_step;
    wxTextCtrl *wxtxt_beat_offset;
    
    //eighth line
    wxTextCtrl *wxtxt_space_tap;
    
    //menu interface
    wxMenuBar *wx_menubar;
    wxMenu *wx_menu_file;
    wxMenu *wx_menu_view;
    wxMenu *wx_menu_fft;
    
    
    //origin part
    wxTimer *err_timer;
    wxTimer *play_timer;
    wxTimer *time_sync;
    wxTimer *recv_message;
    wxTimer *tempo_timer;
    //origin wxButton *search_File;
    
    
    void OnPlay(wxCommandEvent &event);
    void OnStop(wxCommandEvent &event);
    void OnPause(wxCommandEvent &event);
    void OnDropdownPrj(wxCommandEvent &event);
    void OnSelectProject(wxCommandEvent &event);
    void OnDropdownId(wxCommandEvent &event);
    void OnSelectId(wxCommandEvent &event);
    void OnChangeSpeed(wxCommandEvent &event);
    void OnChangeVolume(wxCommandEvent &event);
    void OnSelectMode(wxCommandEvent &event);
    void OnChangePrefs(wxCommandEvent &event);
    
    void OnSelectDevice(wxCommandEvent &event);
    void OnNetwork(wxCommandEvent &event);
    void OnImport(wxCommandEvent &event);
    void OnSetPath(wxCommandEvent &event);
    void OnDevices(wxCommandEvent &event);
    void OnArrangement(wxCommandEvent &event);
    void OnMediaMap(wxCommandEvent &event);
    void OnSaveLabel(wxCommandEvent &event);
    void OnFFT(wxCommandEvent &event);
    void OnUpdateRcdFlag(wxCommandEvent &event);
    void OnRecording(wxCommandEvent &event);
    
    void OnErrTimer(wxTimerEvent &event);
    void OnPlayTimer(wxTimerEvent &event);
    void OnSyncTimer(wxTimerEvent &event);
    void OnRecvTimer(wxTimerEvent &event);
    void OnUpdateTempo(wxTimerEvent &event);
    
    void OnTest(wxCommandEvent &event);
    
    void LabelWidgetsEnable();
    void LabelWidgetsDisable();
    
public:
    MainFrame(const wxString & title);
    
    void SetArngmtName(std::string name);
    //set arngment name
    
    void SetArgmtCheck(bool tof);
    //set arngment check flag
    
    void speedValueReset();
    //reset spped bar and relative value
    
    void resetMusicPara();
    //reset everything in last play to be ready for next play(in play scope)
    
    void resetPrjPara();
    //reset everything in last project to be ready for the next project(in project scope)
    
    void showOnCanvas();
    //show every parameter in the realtive blanks
    //###must be used after selecting prj_name and id_name
    
    void readGlbPref();
    //read global prefs.txt file
    
    void Preparation();
    // called by OnPlay(), in order to split the functionality between preparation
    // and "Play" button being clicked
    
    int AutoChoose();
    //only one prj option, choose it automatically
    //only project has been auto-chosen, return 2;
    //both project and audio_id have benn audo chosen, return 1
    //false with 0 return code
    
};

#endif /* defined(__AudioPlayer__MainFrame__) */
