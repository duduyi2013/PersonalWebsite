//
//  devices.cpp
//  audioplayer
//
//  Created by Joe on 12/11/15.
//
//

#include "audio_player.h"
#include "wx/file.h"

extern GlbPara glbpara;

DevicesList::DevicesList()
: wxDialog(NULL, wxID_ANY, "Devices", wxDefaultPosition, wxSize(230,400)) {
    wxPanel *pan = new wxPanel(this, wxID_ANY);
    
    listbox = new wxListBox(pan, wxID_ANY, wxPoint(-1,-1), wxSize(150, 250));
    button_cancel = new wxButton(pan, ID_DIALOG_DEVICES_CANCEL, "Cancel");
    button_ok = new wxButton(pan, ID_DIALOG_DEVICES_OK, "Confirm");
    
    
    wxBoxSizer *first_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *second_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *whole_sizer = new wxBoxSizer(wxVERTICAL);
    first_line->Add(listbox, wxSizerFlags(0).Align(1).Border(wxALL,5));
    second_line->Add(button_ok, wxSizerFlags(0).Align(1).Border(wxALL,5));
    second_line->Add(button_cancel, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(first_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(second_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    pan->SetSizer(whole_sizer);
    
    SetEscapeId(ID_DIALOG_DEVICES_CANCEL);
    Connect(ID_DIALOG_DEVICES_OK, wxEVT_COMMAND_BUTTON_CLICKED,
            wxCommandEventHandler(DevicesList::OnConfirm));
    Connect(wxEVT_COMMAND_LISTBOX_DOUBLECLICKED,
            wxCommandEventHandler(DevicesList::OnConfirm));
    FindDevices();
}

DevicesList::~DevicesList() {
    Destroy();
}

void DevicesList::FindDevices() {
    int numDevices;
    PaError err;
    const PaDeviceInfo *deviceInfo;
    err = Pa_Initialize();
    if( err != paNoError )
    {
        printf( "ERROR: Pa_Initialize returned 0x%x\n", err );
        Pa_Terminate();
        return ;
    }
    numDevices = Pa_GetDeviceCount();
    if( numDevices < 0 )
    {
        printf( "ERROR: Pa_GetDeviceCount returned 0x%x\n", numDevices );
        Pa_Terminate();
        return ;
    }
    listbox->Append("Default Device");
    int counter = 0;
    for(int i=0; i<numDevices; i++ ) {
        deviceInfo = Pa_GetDeviceInfo( i );
        if (deviceInfo->maxOutputChannels > 0) {
            listbox->Append(deviceInfo->name);
            deviceList.push_back(deviceInfo->name);
            if (glbpara.DeviceName.compare(deviceInfo->name) == 0) {
                listbox->SetSelection(counter + 1);
            }
            std::map<std::string, int>::iterator outputDevices = deviceMap.find(deviceInfo->name);
            if (outputDevices == deviceMap.end()) {
                deviceMap[deviceInfo->name] = i;
            } else {
                glbpara.err_reminder = ERR_SAME_DEVICE_NAME;
                return ;
            }
            counter++;
        }
    }
    Pa_Terminate();
    if (glbpara.DeviceName.empty()) {
        listbox->SetSelection(0);
    }
}

void DevicesList::OnConfirm (wxCommandEvent &WXUNUSED(event)) {
    if (listbox->GetSelection() > 0) {
        int deviceIndex = deviceMap[deviceList[listbox->GetSelection() - 1]];
        PaError err;
        err = Pa_Initialize();
        if ( err != paNoError ) {
            printf( "ERROR: Pa_Initialize returned 0x%x\n", err );
            Pa_Terminate();
            return ;
        }
        const PaDeviceInfo *deviceInfo = Pa_GetDeviceInfo( deviceIndex );
        glbpara.DeviceName = deviceInfo->name;
        wxMessageDialog doublecheck(NULL, wxString::Format("Name = %s\nHost API = %s\n"\
                                                           "Max inputs= %d, Max outputs = %d\n"\
                                                           "Default low input latency   = %8.4f\n"\
                                                           "Default low output latency  = %8.4f\n"\
                                                           "Default high input latency  = %8.4f\n"\
                                                           "Default high output latency = %8.4f\n"\
                                                           "Default sample rate         = %8.2f\n",deviceInfo->name,
                                                           Pa_GetHostApiInfo( deviceInfo->hostApi )->name,
                                                           deviceInfo->maxInputChannels,
                                                           deviceInfo->maxOutputChannels,
                                                           deviceInfo->defaultLowInputLatency,
                                                           deviceInfo->defaultLowOutputLatency,
                                                           deviceInfo->defaultHighInputLatency,
                                                           deviceInfo->defaultHighOutputLatency,
                                                           deviceInfo->defaultSampleRate), "Check Info", wxOK);
        doublecheck.ShowModal();
    } else {
        glbpara.DeviceName = "";
    }
    glbPrefWrite(getFullGlbPref());
    EndModal(SUCCESSFUL);
    Pa_Terminate();
    return ;
}