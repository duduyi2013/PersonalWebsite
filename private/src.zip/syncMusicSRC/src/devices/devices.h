//
//  devices.h
//  audioplayer
//
//  Created by Joe on 12/11/15.
//
//

#ifndef __audioplayer__devices__
#define __audioplayer__devices__

#include "wx/wx.h"


class DevicesList : public wxDialog{
    wxListBox *listbox;
    wxButton *button_ok;
    wxButton *button_cancel;
    std::map<std::string, int> deviceMap;
    std::vector<std::string> deviceList;
    
    
    void OnConfirm (wxCommandEvent &event);
    void FindDevices();
public:
    DevicesList();
    ~DevicesList();
};

#endif /* defined(__audioplayer__devices__) */
