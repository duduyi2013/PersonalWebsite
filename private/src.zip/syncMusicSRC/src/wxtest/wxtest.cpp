//all the dirs within music path will be regarded as project
//this file contains global variables and the wxwidgets main entrance

#include "wx/wx.h"

class MainFrame : public wxFrame {
  public:
    MainFrame(const wxString &title) :
            wxFrame(NULL, -1, title, wxDefaultPosition, wxSize(400, 400)) {
        wxPanel *pan = new wxPanel(this, wxID_ANY);
    }
};

class TestApp : public wxApp {
public:
    virtual bool OnInit();
};

IMPLEMENT_APP(TestApp)

bool TestApp::OnInit(){
    MainFrame *main_frame = new MainFrame("WxTest");
    main_frame->Show(true);
    return true;
}
