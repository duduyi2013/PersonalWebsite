//all the dirs within music path will be regarded as project
//this file contains global variables and the wxwidgets main entrance

#include "audio_player.h"

LinearFunction cur_linear, update_linear, new_linear;
Phase_vocoder* pv;
RefMedMap *final_rmm;
// because of performance reference map and reference media map
// besides the rmm, the final rmm might be composed rmm which is actually pmm (rmm(prm) = pmm)
// so here we add a pointer to represent the final rmm we use

GlbPara glbpara;
PrjPara prjpara;
PlayerPara playerpara;
Audio_buffer buffer;
Rock callbackRock(0, prjpara.pv_fft_size / 2, 0, 1);
RefMedMap rmm;
PerfRefMap prm;
Network network;
MainFrame *main_frame;


//main entrance about the project
//************Description***************
//this is a class for init the program and start it
//***************************

class MusicApp : public wxApp {
public:
    virtual bool OnInit();
};

IMPLEMENT_APP(MusicApp)

bool MusicApp::OnInit() {
    main_frame = new MainFrame("Audio Player");
    main_frame->Show(true);
    return true;
}