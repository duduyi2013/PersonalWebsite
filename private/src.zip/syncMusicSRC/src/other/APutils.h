//
//  APutils.h
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#ifndef __AudioPlayer__APutils__
#define __AudioPlayer__APutils__

#include <string>
#include "BasicClass.h"

bool updateDropdownItems(std::string dir_path, std::vector<std::string> *list, std::string pattern = "");
//update the dropdown list items within dir_path and set the new list into "list"
//pattern is used for filtering the expected name, but "the name" is compared only from the start

bool initPrj();
//initialize when a new project comes

float beatsToTime(float media_beats);
//convert media beat to time based on label track
float Time2Beats (float time, int flag = 0);
//convert time to media beat based on label track
//flag0: return relevant beat, flag1: return index of relevant entry in tempo_track

void glbPrefWrite(std::string glb_pref);
//write contents in APprefs.txt into memory
//glb_pref: file path

bool glbPrefRead(std::string glb_pref);
//read contents in APprefs.txt into memory
//glb_pref: file path

void prefsWrite(std::string pref_path, int flag = 1);
//write contents in prefs.txt into memory
//pref_path: file path, flag = 1 write current configuration into prefs.txt
//flag = 2, write default configuration into prefs.txt

void prefsRead(const char *prefs_path);
//read contents in prefs.txt into memory
//prefs_path: file path

void Convergent(LinearFunction& cur, LinearFunction& update, double start_x);
//convergent from cur linear to update linear with the start point start_x

bool get4FilesPath();
//get four basic files full path, if exists into memory

void getClick();
//read click data into memory

void getLabelTrack(int flag = 0);
//parse the label files and read info into memeory
//flag == 0 means using label track file
//flag == 1 means using fixed tempo with beat1 time

void ReadMapping(std::string file_path);
//read reference-media mapping into memory.

long CalculateFrameLen(RefMedMap& final_rmm, float start_refb, float end_refb = 9999);
// return the sample lenth from ref_beat for playing within ref-media mapping

long ReadBuf(float *buff, long read_len, RefMedMap& final_rmm);
//read a full buffer, because media mapping can prevent
//reading data from simply reading sequentially
//buff: the float pointer to read data in
//read_len: sample lenth for reading this time
//return read_count

void InterleaveOutput(int channels, int index, float *origin, float *destin, long len);
//interleave each channel from origin into destin, index represents the index of channel in process
//len is the length of origin, here it should be frameperbuffer

float GetCurRef(float &cur_time);
//get current time and calculate the current reference beat

float GetOriginCurTempo(float playingTime, RefMedMap& final_rmm);
//in tempo track mode, passed in the playing time, return an original current tempo
#endif