//
//  audio_player_network.cpp
//  wxWidgetTest
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

//#include "audio_player_network.h"
#include "audio_player.h"

extern PlayerPara playerpara;
extern GlbPara glbpara;
extern PrjPara prjpara;
extern MainFrame *main_frame;
extern LinearFunction cur_linear, update_linear, new_linear;
extern PerfRefMap prm;

Network :: Network() {
    id_num = rand() % 10000 ;
    player_num = -1;
    mapping_offset = -1;
    minimal_latency = RAND_MAX;//pick a max value
    last_time = (struct timeval){.tv_sec = 0, .tv_usec = 0};
    context = new zmq::context_t(1);
    sub_socket = NULL;
    push_socket = NULL;
}
void Network::Connect(std::string ip, std::string push_port, std::string sub_port) {
    Disconnect();
    std::string address = "tcp://" + ip + ":";
    sub_socket = new zmq::socket_t(*context, ZMQ_SUB);
    sub_socket->connect((address + sub_port).c_str());
    
    sub_socket->setsockopt(ZMQ_SUBSCRIBE, NULL, 0);
    push_socket = new zmq::socket_t(*context, ZMQ_PUSH);
    push_socket->connect((address + push_port).c_str());
    glbpara.connect_flag = true;
}

void Network::Disconnect() {
    if (sub_socket != NULL) {
        sub_socket->close();
        sub_socket = NULL;
    }
    if (push_socket != NULL) {
        push_socket->close();
        push_socket = NULL;
    }
    glbpara.connect_flag = false;
}

void Network::Join() {
    usleep(100000);
    std::stringstream st;
    st<<"hcmp join "<<id_num<<" MPLYR";
    SendMessage(st.str());
}
//add how to correctly exit
void Network::SendMessage(std::string message) {
    zmq::message_t req_msg(message.size());
    memcpy((void *)req_msg.data(), message.c_str(), message.size());
    //std::cout<<"Send: "<<message<<std::endl;//test
    if (!push_socket->send(req_msg)) {
        printf("Cannot send message!\n");
    }
}

void Network::Listener() {
    zmq::message_t recv_msg;
    if (sub_socket->recv(&recv_msg, ZMQ_DONTWAIT)) {
        struct timeval now;
        gettimeofday(&now, NULL);
        
        std::string str((char*)recv_msg.data(),recv_msg.size());
        //std::cout<<"Str: "<<str<<std::endl;
        std::vector<std::string> tokens = split(str,' ');
        if (tokens[0].compare(0,4,"plr.") != 0) {
            //token[0] is hcmp
            if (prjpara.mode == MODE_CONDUCTOR) {
                if (tokens[1].compare("id") == 0) {
                    if (HandleIdMessage(tokens)) {
                        return ;
                    } else {
                        return ;
                    }
                } else if (tokens[1].compare("load") == 0) {
                    //TODO
                } else if (tokens[1].compare("pos") == 0) {
                    HandlePosMessage(tokens);
                } else if (tokens[1].compare("tm") == 0) {
                    HandleTmMessage(tokens);
                } else if (tokens[1].compare("play") == 0) {
                    HandlePlayMessage(tokens);
                } else if (tokens[1].compare("pause") == 0) {
                    HandlePauseMessage(tokens);
                } else if (tokens[1].compare("stop") == 0) {
                    HandleStopMessage(tokens);
                } else if (tokens[1].compare("arrangement") == 0) {
                    HandleArrangementMessage(tokens);
                }
            }
        } else {//clock sync
            HandleSyncMessage(tokens, now);
        }
    }
}

void Network::timeSync() {
    setLastTime();
    SendMessage("plr." + player_num + " resync");
}

std::string Network::getPlayerNum() {
    return player_num;
}

void Network::setLastTime() {
    gettimeofday(&last_time, NULL);
}

bool Network::isMin(struct timeval now) {
    float now_gap = (now.tv_usec / 1000000.0 + now.tv_sec) / 2;
    if (now_gap >= minimal_latency) {
        return false;
    } else {
        minimal_latency = now_gap;
        return true;
    }
}

double Network::getOffset() {
    return mapping_offset;
}

float Network::getLatency() {
    return minimal_latency;
}
bool Network::HandleSyncMessage(std::vector<std::string> &token, struct timeval now) {
    if (split(token[0], '.').at(1).compare(player_num) == 0) {
        struct timeval gap;
        timersub(&now, &last_time, &gap);
        if (isMin(gap)) {
            mapping_offset =  now.tv_sec + now.tv_usec / 1000000.0
            - atof(token[2].c_str()) - minimal_latency;
        }
        return true;
    } else {
        return false;
    }
}

bool Network::HandleIdMessage(std::vector<std::string> &token) {
    if (atol(token[2].c_str()) == id_num) {
        player_num = token[3];
        return true;
    }
    return false;
}

void Network::HandleLoadMessage(std::vector<std::string> &token) {
    
}

void Network::HandlePosMessage(std::vector<std::string> &token) {
    //test
    //float cur_time;
    //float cur_ref = GetCurRef(cur_time);
    //printf("\n\nPOS--tm:%f, ref:%f\n\n",cur_time,cur_ref);
    //test
    prjpara.start_beat = atof(token[2].c_str());
    main_frame->Preparation();
}

void Network::HandleTmMessage(std::vector<std::string> &token) {
    //test
    //float cur_time;
    //float cur_ref = GetCurRef(cur_time);
    std::cout<<std::endl<<std::endl<<"Update--Tempo : "<< token[4]<< std::endl<< std::endl;
    //printf("CurTempo--tp:%lf\n\n",tests);
    //test
    update_linear.Set(atof(token[2].c_str()), atof(token[3].c_str()), atof(token[4].c_str()));
    if (cur_linear.isStart()) {
        struct timeval cur_time;
        gettimeofday(&cur_time, NULL);
        double start_x = cur_time.tv_sec + cur_time.tv_usec / 1000000.0 - mapping_offset - minimal_latency;
        Convergent(cur_linear, update_linear, start_x);
    } else {
        cur_linear.SetLinear(update_linear);
    }
}

void Network::HandlePlayMessage(std::vector<std::string> &token) {
    //test
    //float cur_time;
    //float cur_ref = GetCurRef(cur_time);
    //printf("\n\nPLAY--tm:%f, ref:%f\n\n",cur_time,cur_ref);
    //test
    glbpara.audio_state = AUDIO_IDLE;
}

void Network::HandlePauseMessage(std::vector<std::string> &token) {
    if (glbpara.audio_state == AUDIO_PLAY) {
        glbpara.audio_state = AUDIO_IDLE;
    }
}

void Network::HandleStopMessage(std::vector<std::string> &token) {
    glbpara.audio_state = AUDIO_STOP;
}

bool Network::HandleArrangementMessage(std::vector<std::string> &token) {
    /*if ((token.size() - 2) % 3 != 0) {
        printf("Err: Conductor send wrong number of parameter in arrangement\n");
        return false;
    }
    int mapping_num = (token.size() - 2) / 3;*/
    int length = token.size();
    if (length > 3) {
        //with the name
        for (int i = 2 ; i < length - 1 ; i++) {
            if (i > 2) {
                glbpara.ArngName += ' ';
            }
            glbpara.ArngName += token[i];
        }
        main_frame->SetArngmtName(glbpara.ArngName);
    }
    std::vector<std::string> entries = split(token[length - 1], ')');
    int mapping_num = entries.size();
    prm.Reset();
    prm.SetAllocate(mapping_num);
    for (int i = 0; i < mapping_num ; i++) {
        std::vector<std::string> item = split(entries[i], ',');
        int end = item.size();
        prm.ref_beat[i] = std::atof(item[end - 2].c_str());
        prm.duration[i] = std::atof(item[end - 1].c_str());
    }
    main_frame->SetArgmtCheck(true);
    return true;
}

Network::~Network() {
    push_socket->close();
    sub_socket->close();
    context->close();
}