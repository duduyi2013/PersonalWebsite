//
//  audio_player.h
//  wxWidgetTest
//
//  Created by Joe on 5/1/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#ifndef wxWidgetTest_audio_player_h
#define wxWidgetTest_audio_player_h

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pwd.h>
#include <time.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <map>

#ifndef _pv_player_h_
#define _pv_player_h_
#include "cmupv.h"
#endif

#ifndef _portaudio_player_h_
#define _portaudio_player_h_
#include "portaudio.h"
#endif

#ifndef _libsndfile_player_h_
#define _libsndfile_player_h_
#include "sndfile.h"
#endif


#include "APutils.h"
#include "Callback.h"
#include "utils.h"
#include "devices.h"
#include "SetPathDialog.h"
#include "ImportDialog.h"
#include "NetworkDialog.h"
#include "MainFrame.h"
#include "BasicClass.h"
#include "audio_player_network.h"
#include "mediamap.h"
#include "wx/wx.h"



enum{
    // it is better not change the sequence of enum, event listening may choose a range of ID
    // to listen, so change the sequence may alter the range
    ID_PLAY = 101,
    ID_STOP,
    ID_PAUSE,
    //ID_SEARCH_FILE,
    ID_PROJECT,
    ID_AUD_ID,
    ID_START_BEAT,
    ID_END_BEAT,
    ID_MODE,
    ID_CHECK_RCD,
    ID_SPEED,
    ID_VOLUME,
    ID_ARRANGEMENT,
    ID_FIRST_BEAT,
    ID_BEAT_STEP,
    ID_BEAT_OFFSET,
    ID_SPACE_TAP,
    
    ID_ERR_TIMER,
    ID_PLAY_TIMER,
    ID_SYNC_TIMER,
    ID_RECV_TIMER,
    ID_TEMPO_TIMER,
    
    ID_MENU_NETWORK,
    ID_MENU_IMPORT,
    ID_MENU_SET_PATH,
    ID_MENU_DEVICE,
    ID_MENU_ARRANGEMENT,
    ID_MENU_MEDIA_MAP,
    ID_MENU_SAVE_LABEL,
    ID_MENU_FFT_256,
    ID_MENU_FFT_512,
    ID_MENU_FFT_1024,
    ID_MENU_FFT_2048,
    ID_MENU_FFT_4096,
    ID_MENU_FFT_8192,
    ID_MENU_FFT_FOURTH,
    ID_MENU_FFT_EIGHTH,
    ID_MENU_FFT_SIXTEENTH,
    
    ID_DIALOG_NETWORK_CONNECT,
    ID_DIALOG_NETWORK_CANCEL,
    
    ID_DIALOG_IMPORT_AUDIO_SEARCH,
    ID_DIALOG_IMPORT_LABEL_SEARCH,
    ID_DIALOG_IMPORT_CLICK_SEARCH,
    ID_DIALOG_IMPORT_OK,
    ID_DIALOG_IMPORT_CANCEL,
    
    ID_DIALOG_MUSIC_PATH_SEARCH,
    ID_DIALOG_MUSIC_PATH_OK,
    ID_DIALOG_MUSIC_PATH_CANCEL,
    
    ID_DIALOG_MEDIA_MAPPING_OK,
    ID_DIALOG_MEDIA_MAPPING_CANCEL,
    ID_TEST,
    
    ID_DIALOG_DEVICES_OK,
    ID_DIALOG_DEVICES_CANCEL
};

enum{
    ERR_EMPTY_FILE = 1,
    ERR_NON_PATH,
    ERR_PREF_NEXIST,
    ERR_PA_INIT,
    ERR_PA_OPEN,
    ERR_PA_START,
    ERR_PA_CLOSE,
    ERR_PA_STOP,
    ERR_SND_OPEN,
    ERR_SND_CLICK_OPEN,
    ERR_SND_CLICK_NONEXIST,
    ERR_CHANNEL,
    ERR_PV_INVALID_INPUTCOUNT,
    ERR_WEIRD_AUDIO_STATE,
    ERR_EMPTY_GLB_PREF,
    ERR_INVALID_STOP,
    ERR_INVALID_PLAY,
    ERR_STARTBEAT_FORMAT,
    ERR_ENDBEAT_FORMAT,
    ERR_ENDBEAT_LESS_THAN_STARTBEAT,
    ERR_SAME_DEVICE_NAME,
    ERR_LABEL_UNFINISHED,
    FINISH
};//reminder messagebox type

// the member in preference file
#define DEFAULT_START_BEAT 0
#define DEFAULT_END_BEAT 9999
#define DEFAULT_ARRAGEMENT 0
#define DEFAULT_MODE 0
#define DEFAULT_TEMPO_SCALE 1
#define DEFAULT_TEMPO 0
#define DEFAULT_VOLUME 1
#define DEFAULT_FFTSIZE 2048
#define DEFAULT_HOPSIZE 256
#define DEFAULT_FIXED_TEMPO 100
#define DEFAULT_START_TIME 0
#define DEFAULT_FIRST_BEAT 0
#define DEFAULT_BEAT_STEP 2
#define DEFAULT_BEAT_OFFSET 0

#define MODE_TEMPO_TRACK 0
#define MODE_OVERRIDE 1
#define MODE_CONDUCTOR 2
#define MODE_LABEL 3

#define APPATH_NOT_EXIST 0
#define APPATH_DIR  1
#define APPATH_FILE 2
#define APPATH_ERR  -1

#define BLOCK_SIZE (256)  //set manually, should be the same with blocksize in pv
#define READ_BLOCK (1024*1024) // the size of bytes for each buffer
#define CLICK_BUFF_SIZE (READ_BLOCK / 1024 * 30) //click buff size

#define INFINITE_BEAT 9999 //this num doesn't actually mean the 9999th beat
                           //it means the end of the file
#define ERROR_INTERVAL 500 //interval time between wxtimer periodically checking err_id
#define READ_CHECK_INTERVAL 10 //periodically fill buffer from file while playing
#define TEMPO_UPDATE_INTERVAL 10 // periodically update the tempo and show on canvas

//audio status, default is audio_stop
#define AUDIO_IDLE 0x0001 //intrigued by pause function
#define AUDIO_PLAY 0x0002
#define AUDIO_STOP 0x0004


#define UNSUCCESSFUL 0
#define SUCCESSFUL 1 //wxDialog returns
#define HOSTIP_LOCALHOST 2
#define HOSTIP_NONE 3

#define DAMP_DUR 1.2f //damp player at the end
#define CONVERGENT_D 1 //convergent steps vt
#define EQUAL_RANGE 0.006f 
// within this range, we consider there is no difference,
// this means two numbers don't have to be exactly the same

#define LINEAR_INI_VALUE -10000 
//initial value for linear function

#define START_OFFSET 0.03f 
// when ref turns 0, music should start, this is a cushion space
// when vt skips 0 a little bit and we didn't detect it when it is 0


//update the combo dropdown list and pass the name in to parameter list

#endif


