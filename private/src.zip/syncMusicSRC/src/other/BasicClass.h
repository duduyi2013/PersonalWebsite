//
//  BasicClass.h
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#include "audio_player.h"
#ifndef __AudioPlayer__BasicClass__
#define __AudioPlayer__BasicClass__

class Audio_buffer {
    
public:
    long samps_per_block;
    float *input_data;
    float *data;
    long cur_buff;
    long next_buff;
    long sample_count;
    //add change public here
    void Initialize(long read_block_bytes);
    //it is not in the construction function, because the size of buffer should be based on the number of channels
    //in music file, so the buff should be generate after the music fiile structure is known
    
    Audio_buffer();
    ~Audio_buffer();
    
    long get_samps_per_block();
    float *get_read_ptr();
    long get_sample_count();
    long get_remainder();
    
    void took(long n);
    
    float *ready_for_more();
    
    void write_completed();
    
    bool isValid();//return true if pointer "data" is not null
    
    void resetClass();
    //the size of each buffer should change based on the number of channels in music file
    //so whenever I switch to a project, this function should be called to customized its buff size to
    //the channels;
    
    void resetBuffer();
    //this is for reset the parameters in playing, so this should be called every time the music plays
    
    float *next_buffer();
    
};

class Rock{
    int num_channels;
    int cur_index;
    double last_in_count;
    double last_out_count;
    long hop_size;
    double cur_tempo_scale;
    
public:
    Rock(double last_in, double last_out, long hop_size, double tmp_scale);
    void setLast(double last_in, double last_out, long hop_size, double tmp_scale);
    double getLastIn();
    double getLastOut();
    double getCurTempo();
    void setChannels(int channels);
    void indexStep();
    int getChannels();
    int getIndex();
    long getCurHopSize();
    void reset();
};  // used to compute hopsize in callback


class LinearFunction{
    double x_start;
    double y_start;
    double slope;
public:
    LinearFunction();
    LinearFunction(double x, double y, double new_slope);
    bool isStart();
    bool isEqualTo(LinearFunction& target);
    float GetIntersectX(LinearFunction& target);
    float GetIntersectY(LinearFunction& target);
    //calculate x and y of the intersection
    void Reset();
    void SetLinear(LinearFunction& new_one);
    double getY(double x);
    double getX(double y);
    void Set(double x, double y, double new_slope);
    void Get(double &x, double &y, double &s);
};

class RefMedMap{
public:
    float *ref_beat;
    float *med_beat;
    float *duration;
    float *time_gap;
    // point to a list of time gap within each media mapping entry
    float total_time;
    // that may not be the total time in media file, cuz the med beat related to the start ref beat
    // is not actually the start of media file
    int mapping_num;
    float cur_read_ref_beat;
    //the current ref-b only for file reading, is not equal to current reference beat
    //should always be valid ref_beat: some ref_b may relate to silence, this beat can
    int cur_read_ref_index;
    //the index of the same duration of cur_read_ref_beat
    std::vector<float> timelen_eachgap;
    //point to every sample lenth from start of the reference beat map to each gap point
    
    RefMedMap();
    RefMedMap(int num);
    //contructor with known number of entry will automatically allocate memory for each pointers
    ~RefMedMap();
    void Reset();
    
    void FillEntriesFromSheet(std::vector<std::string> sheet);
    // fill the content each pointer pointing to, with tokens
    void SetAllocate(int num);
    // allocate num float to each pointers
    void RestartMusc();
    // reset the parameter when music starts again
    float Ref2Media(float ref);
    // return -1 ref doesn't have related media beat
    bool IsNull();
    // detect if current class is avaliable; return true if not avaliable
    float GetRemainFrameCount();
    // return the left frame count of current duration
    float GetTmSpan(float ref_beat);
    // given the reference beat and calculate the time from the start of ref beat
    // e.g. the ref-media mapping may say reference start from beat 2, however, the conductor
    // says let's play from beat 3. In this situation, this function will also calculate from
    // reference 2.
    // returns time spent of the last valid ref_beat if current ref_beat
    // is invalid (e.g. ref1-ref8 and ref9-ref16 is ref-med mapping,
    // ref_beat between 8 and 9 related to no media_beat)
    int GetIndexOfRef(float ref_beat);
    // calculate the index of entry in which ref_beat lies
    // -1 occur for example when the begining of ref_beat is 2, however we try to
    // start at ref_beat 1, there is no data before that.
    // plus, if the tail of the former duration is the head of
    // current duration(they are consecutive), then the intersection point belongs to the current index
};

class PerfRefMap {
public:
    float *ref_beat;
    float *duration;
    RefMedMap *my_pmm;
    //pmm along with prm and rmm, any one of them changes, this pointer should change too
    int mapping_num;
    
    PerfRefMap();
    ~PerfRefMap();
    void SetAllocate(int mapping_num);
    // pass in the number of mapping entries, set and allocate the member variable
    void Reset();
    bool IsNull();
    // detect if current class is avaliable; return true if not avaliable
    RefMedMap* SetPMM(RefMedMap& origin);
    // analyse current performance reference map(prm) and detach it to a new performance media map(pmm)
    // based on the original reference media map, which is actually the same format of reference media map(rmm).
    // e.g. prm{5, 10}, rmm{5,0,3; 10,0,3}, this function will return a pmm{0,0,3; 5,0,3}
};

class PrjPara{
public:
    std::vector<float> tapping_timing;
    int tapping_num;
    // number of tappings
    
    float *click_buff;
    long click_length;
    
    std::string wav_file;
    std::string lab_file;
    std::string pref_file;
    std::string rmm_file;
    std::string click_file;
    // four paths for wav file, label-track file, local preference file and reference media mapping file
    
    long label_length;
    float *label_start_time;
    float *label_stop_time;
    float *label_index_beats;
    // three buffers for each entry in label-track file

    bool stableTempo;
    long read_per_time;
    // the actual size of buffer when reading from disk, it is related to the number of channels
    
    // variable in prefs file
    double start_beat;
    double end_beat;
    int arrag; // arrangement check box
    int mode; //three modes to choose
    float tempo_scale; //tempo_scale
    float tempo;
    float volume;
    int pv_fft_size;
    int pv_hop_size;
    double fixed_tempo;
    // if w/o label_track file specified, we can specify the constant tempo when import a project
    double fixed_tempo_starttime;
    // with fixed tempo, we also need to know where is the music beat 1, it may be not from the sample 0
    double first_beat;
    double beat_step;
    double beat_offset;
    
    PrjPara();
    void reset();
};

class SegmentalMapping{
    float* xs;
    float* ys;
    float* slopes;
    int mysize;
    int filledCount;
public:
    SegmentalMapping();
    SegmentalMapping(long size);
    void reset();
    
    void allocate(long size);
    float getX(float y);
    float getY(float x);
    void update(float x, float y, float slope);
};

class PlayerPara{
public:
    SegmentalMapping sgmtMap;
    
    long pv_callback_count;
    
    long click_offset;// click offset in output buffer, means it may not sync from the beginning of output buffer
    long index_label;// index in label file, point to the entry being synced
    bool isClicking;//clicking trigger, true to sync click
    long sync_pos;// point to the index in click_buff when sync clicking 
    long output_frame_count;
    
    float originCurTempo;
    int ref_state;
    // another flag indicating whether current reference beat
    // will be played (sometimes the current ref beat refers to invalid media beat)
    // but audio_state must be in the higher priority

    long readcount;
    // each time amount of samples read from file
	long last_sample;
    // the sample length from start of media to the end refb
	long first_frame;
    // the sample length from start of media file (maybe not medb 0) to the start refb
    long player_start_samplen;
    // the sample length from refb 0 to the start refb
    int indexofgap;
    // recording the upcoming gap index
    bool gapFlag;
    // flag indicating whether there is a gap coming
    
    float **play_data_each;
    //store channels number of pointers pointing to pv(each channel) out data
    bool end_flag;
    //indicates if this is the last buffer
    long frame_lenth;
    // indicating the playback total length of frame
    bool audio_file_has_data;
    
    bool OnConvergence = false;
    // indicate if current mapping is on convergence

    PlayerPara();
    void reset();
};

class GlbPara{
public:
    std::string DeviceName; // -1 means default, otherwise the index of each device
    std::string ArngName;// arrangement name
    PaStreamParameters outputPara;
    bool rcd;//recording or sync under label mode
    long read_per_time;
    // an prefered size of data read from disk per time, but the actual number need to
    // be fluctuate around it according to the channels, because the size of data read per time
    // has to be the multiple of channels
    int audio_state;
    // upper layer state of audio by controlling
    int err_reminder;
    //reminder messagebox type, uniform error messagebox or finish massagebox
    bool connect_flag;
    //indicates whether try to connect the conductor
    //but not sure about whether the connection is established
    int framePerBuffer;//add init with a general value
    
    std::string glb_pref_name;
    // global preference name, currently only in mac os "HCMP/APprefs.txt"
    
    char *music_path;
    char *prj_name;
    char *aud_name;
    // three path names represent music file path, project files' name, audio-IDs' name
    
    std::vector<std::string> project_list;
    std::vector<std::string> id_list;
    // two lists represent the project dropdown list and audio_id drop down list
    
    GlbPara();
};
#endif /* defined(__AudioPlayer__BasicClass__) */
