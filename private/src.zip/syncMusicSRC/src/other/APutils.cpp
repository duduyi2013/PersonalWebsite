//
//  APutils.cpp
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//
#include "audio_player.h"

//vars in prefs file
extern PrjPara prjpara;
extern PlayerPara playerpara;
extern GlbPara glbpara;

extern LinearFunction new_linear;
extern LinearFunction cur_linear;
extern RefMedMap rmm;
extern Network network;
extern Audio_buffer buffer;

extern SF_INFO	sfinfo;
extern SNDFILE *click_infile;
extern SF_INFO click_sfinfo;
extern SNDFILE *infile;

bool updateDropdownItems(std::string dir_path, std::vector<std::string> *list, std::string pattern) {
    list->clear();
    DIR *dir;
    struct dirent *entry;
    int dir_num = 0;
    std::string full_path;
    
    if ((dir = opendir (dir_path.c_str())) != NULL) {
        // only not hidden directories within dir_path will be added to list
        while ((entry = readdir (dir)) != NULL) {
            if (entry->d_name[0] == '.')
                continue;
            list->push_back(entry->d_name);
            full_path = dir_path + "/" + entry->d_name;
            int file_stat = getPathStatus(&full_path);
            if (file_stat == APPATH_DIR) {
                if (((std::string)entry->d_name).compare(0,pattern.length(),pattern) != 0) {
                    list->pop_back();
                } else if (getSonDirNum(full_path) == 0) {//detect whether the entry has content
                    list->pop_back();
                } else {
                    dir_num++;
                }
            } else if ( file_stat == APPATH_FILE) {
                list->pop_back();
            } else if ( file_stat == APPATH_NOT_EXIST) {
                wxMessageDialog error(NULL, wxString::Format("Cannot read info of path %s"
                                                             , full_path.c_str()), "Path Error", wxOK);
                error.ShowModal();
                list->clear();
                return false;
            } else if ( file_stat == APPATH_ERR) {
                wxMessageDialog error(NULL, wxString::Format("Path exists but is not a directory nor a file"
                                                             , full_path.c_str()), "Path Error", wxOK);
                error.ShowModal();
                list->clear();
                return false;
            }
        }
        closedir (dir);
        return true;
    } else {
        glbpara.err_reminder = ERR_NON_PATH;
        list->clear();
        return false;
    }
}
bool initPrj() {
    if (!get4FilesPath()) {
        return false;
    }
    
    //read prefs para into global vars
    const char *ch_pref = prjpara.pref_file.c_str();
    prefsRead(ch_pref);
    
    //read clik file
    if (!prjpara.click_file.empty()) {
        getClick();
    }
    //read label file or fixed tempo
    if (!prjpara.lab_file.empty()) {
        getLabelTrack();
    } else {
        getLabelTrack(1);
    }
    //read ref-media mapping
    if (!prjpara.rmm_file.empty()) {
        ReadMapping(prjpara.rmm_file);
    }
    return true;
}

float beatsToTime(float media_beats) {
    media_beats++;
    int i = 0;
    float time;
    while (prjpara.label_index_beats[i] < media_beats && i < prjpara.label_length) {
        i++;
    }
    if (i == prjpara.label_length) {
        i--;
    } else if (i == 0) {
        i++;
    }
    if (prjpara.label_index_beats[i] == media_beats) {
        time = prjpara.label_start_time[i];
    } else {
        time = (prjpara.label_start_time[i] - prjpara.label_start_time[i - 1])
        * (media_beats - prjpara.label_index_beats[i - 1])
        / (prjpara.label_index_beats[i] - prjpara.label_index_beats[i - 1])
        + prjpara.label_start_time[i - 1];
    }
    return time;
}

float Time2Beats (float time, int flag) {
    int i = 0;
    float beat;
    while(prjpara.label_start_time[i] < time && i < prjpara.label_length) {
        i++;
    }
    if (i == prjpara.label_length) {
        i--;
    } else if (i == 0) {
        i++;
    }
    if (prjpara.label_start_time[i] == time) {
        beat = prjpara.label_index_beats[i];
    } else {
        beat = (prjpara.label_index_beats[i] - prjpara.label_index_beats[i - 1])
        / (prjpara.label_start_time[i] - prjpara.label_start_time[i - 1])
        * (time - prjpara.label_start_time[i]) + prjpara.label_index_beats[i];
    }
    if (flag == 0) {
        return beat - 1;
    } else {
        return i - 1;
    }
}

void glbPrefWrite(std::string glb_pref) {
    std::ofstream glb_pref_file;
    glb_pref_file.open(glb_pref.c_str());
    glb_pref_file << glbpara.music_path << ";" << glbpara.prj_name << ";" << glbpara.aud_name << std::endl;
    if (!glbpara.DeviceName.empty()) {
        glb_pref_file << glbpara.DeviceName << std::endl;
    }
    glb_pref_file.close();
}

bool glbPrefRead(std::string glb_pref) {
    std::ifstream glb_pref_file(glb_pref.c_str());
    std::string AP_full_path;
    std::vector<std::string> AP_seperate_path;//0:APhome_path, 1:APproj_name, 2:APid_name,
    
    getline(glb_pref_file, AP_full_path);
    getline(glb_pref_file, glbpara.DeviceName);
    AP_seperate_path = split(AP_full_path, ';');
    int size = AP_seperate_path.size();
    if (size == 0) {
        return false;
    } else {
        if (AP_seperate_path[0].find('/') == std::string::npos) {
            return false;
        }
    }
    if (glbpara.music_path) {
        free(glbpara.music_path);
        glbpara.music_path = NULL;
    }
    if (glbpara.prj_name) {
        free(glbpara.prj_name);
        glbpara.prj_name = NULL;
    }
    if (glbpara.aud_name) {
        free(glbpara.aud_name);
        glbpara.aud_name = NULL;
    }
    glbpara.music_path = (char*) malloc(sizeof(char) * (AP_seperate_path[0].size() + 1));
    strcpy(glbpara.music_path, AP_seperate_path[0].c_str());
    
    if (size >= 2) {
        glbpara.prj_name = (char*) malloc(sizeof(char) * (AP_seperate_path[1].size() + 1));
        strcpy(glbpara.prj_name, AP_seperate_path[1].c_str());
    }
    if (size >= 3) {
        glbpara.aud_name = (char*) malloc(sizeof(char) * (AP_seperate_path[2].size() + 1));
        strcpy(glbpara.aud_name, AP_seperate_path[2].c_str());
    }
    glb_pref_file.close();
    return true;
}
void prefsWrite(std::string pref_path, int flag) {
    std::ofstream pref_file;
    pref_file.open(pref_path.c_str());
    
    if (pref_file.is_open()) {
        if (flag == 1) {
            pref_file << "start_beat : " << prjpara.start_beat << std::endl;
            pref_file << "end_beat : " << prjpara.end_beat << std::endl;
            pref_file << "arrangement : " << prjpara.arrag << std::endl;
            pref_file << "mode : " << prjpara.mode << std::endl;
            pref_file << "tempo_scale : " << prjpara.tempo_scale << std::endl;
            pref_file << "tempo : " << prjpara.tempo << std::endl;
            pref_file << "volume : " << prjpara.volume << std::endl;
            pref_file << "fftsize : " << prjpara.pv_fft_size << std::endl;
            pref_file << "hopsize : " << prjpara.pv_hop_size << std::endl;
            pref_file << "fixed_tempo : " << prjpara.fixed_tempo << std::endl;
            pref_file << "beat1_time : " << prjpara.fixed_tempo_starttime << std::endl;
            pref_file << "first_beat : " << prjpara.first_beat << std::endl;
            pref_file << "beat_step : " << prjpara.beat_step << std::endl;
            pref_file << "beat_offset : " << prjpara.beat_offset << std::endl;
            pref_file.close();
        } else {
            pref_file << "start_beat : " << DEFAULT_START_BEAT << std::endl;
            pref_file << "end_beat : " << DEFAULT_END_BEAT << std::endl;
            pref_file << "arrangement : " << DEFAULT_ARRAGEMENT << std::endl;
            pref_file << "mode : " << DEFAULT_MODE << std::endl;
            pref_file << "tempo_scale : " << 1.0f << std::endl;
            pref_file << "tempo : " << DEFAULT_TEMPO << std::endl;
            pref_file << "volume : " << DEFAULT_VOLUME << std::endl;
            pref_file << "fftsize : " << DEFAULT_FFTSIZE << std::endl;
            pref_file << "hopsize : " << DEFAULT_HOPSIZE << std::endl;
            if (prjpara.lab_file.empty()) {
                pref_file << "fixed_tempo : " << DEFAULT_FIXED_TEMPO << std::endl;
                pref_file << "beat1_time : " << DEFAULT_START_TIME << std::endl;
            } else {
                pref_file << "fixed_tempo : " << 0 << std::endl;
                pref_file << "beat1_time : " << 0 << std::endl;
            }
            pref_file << "first_beat : " << DEFAULT_FIRST_BEAT << std::endl;
            pref_file << "beat_step : " << DEFAULT_BEAT_STEP << std::endl;
            pref_file << "beat_offset : " << DEFAULT_BEAT_OFFSET << std::endl;
        }
    } else {
        glbpara.err_reminder = ERR_PREF_NEXIST;
    }
    pref_file.close();
}

void prefsRead(const char *prefs_path) {
    std::string line;
    std::ifstream io_prefs_file(prefs_path);
    int i = 0;
    if(io_prefs_file.is_open()) {
        while( getline(io_prefs_file, line)) {
            std::vector<std::string> items = split(line, ' ');
            switch (i) {
                case 0:
                    prjpara.start_beat = atof(items[2].c_str());
                    break;
                case 1:
                    prjpara.end_beat = atof(items[2].c_str());
                    break;
                case 2:
                    prjpara.arrag = atoi(items[2].c_str());
                    break;
                case 3:
                    prjpara.mode = atoi(items[2].c_str());
                    break;
                case 4:
                    prjpara.tempo_scale = atof(items[2].c_str());
                    break;
                case 5:
                    prjpara.tempo = atof(items[2].c_str());
                    break;
                case 6:
                    prjpara.volume = atof(items[2].c_str());
                    break;
                case 7:
                    prjpara.pv_fft_size = atoi(items[2].c_str());
                    break;
                case 8:
                    prjpara.pv_hop_size = atoi(items[2].c_str());
                    break;
                case 9:
                    prjpara.fixed_tempo = atof(items[2].c_str());
                    break;
                case 10:
                    prjpara.fixed_tempo_starttime = atof(items[2].c_str());
                    break;
                case 11:
                    prjpara.first_beat = atof(items[2].c_str());
                    break;
                case 12:
                    prjpara.beat_step = atof(items[2].c_str());
                    break;
                case 13:
                    prjpara.beat_offset = atof(items[2].c_str());
                    break;
                default:
                    wxMessageDialog err(NULL, "More lines than expected in prefs"
                                        , "Error", wxOK);
                    break;
            }
            i++;
        }
    } else {
        glbpara.err_reminder = ERR_PREF_NEXIST;
    }
    io_prefs_file.close();
}

void getClick() {
    if (!(click_infile = sf_open (prjpara.click_file.c_str(), SFM_READ, &click_sfinfo))) {
        glbpara.err_reminder = ERR_SND_CLICK_OPEN;
        return  ;
    }
    prjpara.click_length = sf_read_float(click_infile, prjpara.click_buff, CLICK_BUFF_SIZE / sizeof(float));
}

void getLabelTrack(int flag) {
    if (flag == 0) {
        const char *ch_lab = prjpara.lab_file.c_str();
        std::string line;
        std::vector<std::string> label_track;
        std::ifstream io_label_file(ch_lab);
        if (io_label_file.is_open()) {
            while (getline(io_label_file, line)) {
                label_track.push_back(line);
            }
        }
        io_label_file.close();
        
        prjpara.label_length = label_track.size();
        prjpara.label_start_time = new float[prjpara.label_length];
        prjpara.label_stop_time = new float[prjpara.label_length];
        prjpara.label_index_beats = new float[prjpara.label_length];
        
        for (int i = 0 ; i < prjpara.label_length; i++) {
            std::vector<std::string> entry = split(label_track[i], ' ');
            prjpara.label_start_time[i] = std::atof(entry[0].c_str());
            prjpara.label_stop_time[i] = std::atof(entry[1].c_str());
            prjpara.label_index_beats[i] = std::atof(entry[2].substr(1).c_str());
            
            //if any line in labeltrack except the first line
            //has a 0 value, it is in the wrong format
            if (prjpara.label_start_time == 0 || prjpara.label_stop_time == 0 || prjpara.label_index_beats == 0) {
                if (i > 0) {
                    wxMessageDialog err(NULL,wxString::Format("Line No.:%d in labeltrack\
                                                              in a wrong format"),"LabelTrack Err", wxOK);
                    err.ShowModal();
                }
            }
        }
        prjpara.stableTempo = false;
    } else if (flag == 1) {
        prjpara.label_length = 2;
        prjpara.label_start_time = new float[prjpara.label_length];
        prjpara.label_stop_time = new float[prjpara.label_length];
        prjpara.label_index_beats = new float[prjpara.label_length];
    
        prjpara.label_start_time[0] = prjpara.fixed_tempo_starttime;
        prjpara.label_stop_time[0] = prjpara.fixed_tempo_starttime;
        prjpara.label_index_beats[0] = 0;
        
        prjpara.label_start_time[1] = prjpara.fixed_tempo_starttime + 60;
        prjpara.label_stop_time[1] = prjpara.fixed_tempo_starttime + 60;
        prjpara.label_index_beats[1] = 0 + prjpara.fixed_tempo;
        prjpara.stableTempo = true;
        playerpara.originCurTempo = prjpara.fixed_tempo;
    }
}

bool get4FilesPath() {
    std::string files_path = (std::string)(glbpara.music_path) + "/" + glbpara.prj_name + "/" + glbpara.aud_name;
    
    //pre-read labeled file and prefs in the dir
    DIR *dir;
    struct dirent *entry;
    if ((dir = opendir (files_path.c_str())) != NULL) {
        // only directories within music_path will be added to project_list
        while ((entry = readdir (dir)) != NULL) {
            if (entry->d_name[0] == '.') continue;
            std::string fname = entry->d_name;
            std::string extension = fname.substr(fname.length()-3,3);
            if (extension.compare("wav") == 0) {
                if (fname.compare("click.wav") == 0) {
                    prjpara.click_file = files_path + "/" + fname;
                } else {
                    prjpara.wav_file = files_path + "/" + fname;
                }
            } else if (extension.compare("txt") == 0) {
                if(fname.compare(0,5,"prefs") == 0) {
                    prjpara.pref_file = files_path + "/" + fname;
                } else if (fname.compare(0,12,"mediamapping") == 0) {
                    prjpara.rmm_file = files_path + "/" + fname;
                } else {
                    prjpara.lab_file = files_path + "/" + fname;
                }
            }
        }
        closedir (dir);
    } else {
        wxMessageDialog err(NULL, wxString::Format("No such directory: %s"
                                                   , files_path.c_str()),"Error",wxOK);
        err.ShowModal();
        //add disable all the playing buttons
    }
    if (prjpara.wav_file.empty()) {
        wxMessageDialog err(NULL, wxString::Format(".wav file not found for this project"),"Error",wxOK);
        err.ShowModal();
        return false;
    }
    if (prjpara.pref_file.empty() || !hasContent(prjpara.pref_file)) {
        prjpara.pref_file = files_path + "/prefs.txt";
        prefsWrite(prjpara.pref_file,2);
        wxMessageDialog err(NULL, wxString::Format("prefs.txt file not found for this project, automatically create a default one instead"),"Warning",wxOK);
        err.ShowModal();
    }
    return true;
}

void ReadMapping(std::string file_name) {
    const char *ch_mapping = file_name.c_str();
    std::string line;
    std::vector<std::string> mapping_entries;
    std::ifstream io_mapping_file(ch_mapping);
    if (io_mapping_file.is_open()) {
        while (getline(io_mapping_file, line)) {
            mapping_entries.push_back(line);
        }
    } else {
        printf("Cannot Open RMM File: Ignore RM mapping\n");
        //add change it to wxwidgets, need another
        //reminder string for detail
        return ;
    }
    io_mapping_file.close();
    
    rmm.SetAllocate(mapping_entries.size());
    rmm.FillEntriesFromSheet(mapping_entries);
    rmm.cur_read_ref_beat = rmm.ref_beat[0];
}

long ReadBuf(float *buff, long read_len, RefMedMap& final_rmm) {//multi-channels
    int read_count = 0;
    if (final_rmm.IsNull()) {
        read_count = sf_read_float(infile, buff, read_len);
    } else {//fill buf within media mapping
        long remain_frame;
        int channels = sfinfo.channels;
        //int times= 0;
        while ((remain_frame = final_rmm.GetRemainFrameCount()) <= (read_len - read_count) / channels) {//multi-channel
            /*printf("%d Remain:%ld; ReadCount:%ld; Index:%d; RefB:%lf\n",times++,remain_sample, read_count, rmm.cur_read_ref_index, rmm.cur_read_ref_beat);*///test
            read_count += sf_read_float(infile, buff + read_count, remain_frame * channels);
            final_rmm.cur_read_ref_index++;
            if (final_rmm.cur_read_ref_index >= final_rmm.mapping_num) {
                return read_count;
            }
            final_rmm.cur_read_ref_beat = final_rmm.ref_beat[final_rmm.cur_read_ref_index];
            sf_seek(infile, beatsToTime(final_rmm.med_beat[final_rmm.cur_read_ref_index])
                    * sfinfo.samplerate, SEEK_SET);//multi-channels
        }
        if (read_len > read_count) {
            /*printf("1%d Remain:%ld; ReadCount:%ld; Index:%d; RefB:%lf\n",times++,remain_sample, read_count, rmm.cur_read_ref_index, rmm.cur_read_ref_beat);*///test
            float start_med_beat = final_rmm.Ref2Media(final_rmm.cur_read_ref_beat);
            float start_time = beatsToTime(start_med_beat);
            long left_lenth = read_len - read_count;
            float end_time = start_time + (float)left_lenth / (channels * sfinfo.samplerate);//multi-channels
            final_rmm.cur_read_ref_beat += Time2Beats(end_time) - start_med_beat;
            int rc_each = sf_read_float(infile, buff + read_count, left_lenth);
            read_count += rc_each;
            if (rc_each != left_lenth) {
                return read_count;
            }
            /*printf("1%d Remain:%ld; ReadCount:%ld; Index:%d; RefB:%lf Left:%ld\n",times++,remain_sample, read_count, rmm.cur_read_ref_index, rmm.cur_read_ref_beat,left_lenth);
            printf("1%d SMedB:%f; ST:%f; ET:%f; T2B:%f\n",times++,start_med_beat, start_time, end_time, Time2Beats(end_time));*///test
        }
    }
    return read_count;
}

void Convergent(LinearFunction& cur, LinearFunction& update, double start_x) {
    double start_y = cur.getY(start_x);
    double end_x = update.getX(start_y + CONVERGENT_D);
    double new_slope = CONVERGENT_D / (end_x - start_x);
    new_linear.Set(start_x, start_y, new_slope);
}

long CalculateFrameLen(RefMedMap& final_rmm, float start_refb, float end_refb) {
    int i;
    float start_total_time = 0, end_total_time;
    if (end_refb != 9999) {
        end_total_time = 0;
    } else {
        end_total_time = final_rmm.total_time;
    }
    for (i = 0; i < final_rmm.mapping_num ; i++) {
        if (final_rmm.ref_beat[i] <= start_refb) {
            if (start_refb < final_rmm.ref_beat[i] + final_rmm.duration[i]) {
                start_total_time += beatsToTime(final_rmm.Ref2Media(start_refb)) - beatsToTime(final_rmm.med_beat[i]);
                break;
            }
            start_total_time += final_rmm.time_gap[i];
            if (end_refb != 9999) {
                end_total_time = start_total_time;
            }
        } else {
            break;
        }
    }
    playerpara.player_start_samplen = start_total_time * sfinfo.samplerate;//multi-channels
    if (end_refb != 9999) {
        for (; i < final_rmm.mapping_num; i++) {
            if (final_rmm.ref_beat[i] <= end_refb) {
                if (end_refb < final_rmm.ref_beat[i] + final_rmm.duration[i]) {
                    end_total_time += beatsToTime(final_rmm.Ref2Media(end_refb)) - beatsToTime(final_rmm.med_beat[i]);
                    break;
                }
                end_total_time += final_rmm.time_gap[i];
            } else {
                break;
            }
        }
    }
    return (end_total_time - start_total_time) * sfinfo.samplerate;//multi-channels
}

float GetCurRef(float &cur_time) {
    struct timeval cur;
    gettimeofday(&cur, NULL);
    cur_time = cur.tv_sec + cur.tv_usec / 1000000.0
                     - network.getLatency() - network.getOffset();
    return cur_linear.getY(cur_time);
}

void InterleaveOutput(int channels, int index, float *origin, float *destin, long len){
    for (int i = 0; i < len; i++) {
        destin[index + i * channels] = origin[i];
    }
}

float GetOriginCurTempo(float playingTime, RefMedMap& final_rmm) {
    int mappingEntryIndex = -1;
    float temp_playtime = playingTime;
    float timeOffset = 0;
    if (!final_rmm.IsNull()) {
        int i;
        for (i = 0; temp_playtime > 0; i++) {
            temp_playtime -= final_rmm.time_gap[i];
        }
        mappingEntryIndex = i - 1;
        timeOffset = temp_playtime + final_rmm.time_gap[i - 1];
        int tempTrackIndex = Time2Beats(beatsToTime(final_rmm.med_beat[mappingEntryIndex]) + timeOffset, 1);
        return (prjpara.label_index_beats[tempTrackIndex + 1] - prjpara.label_index_beats[tempTrackIndex]) / (prjpara.label_start_time[tempTrackIndex + 1] - prjpara.label_start_time[tempTrackIndex]) * 60;
    } else {
        return -1;
    }
}

