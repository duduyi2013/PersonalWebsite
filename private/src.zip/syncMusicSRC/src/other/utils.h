//
//  audioplayerutils.h
//  AudioPlayer
//
//  Created by Joe on 6/22/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#ifndef __AudioPlayer__audioplayerutils__
#define __AudioPlayer__audioplayerutils__
#include <string>
#include "wx/wx.h"

void audCpfile(const char *src, const char *des);
// copy file from src to des

int getSonDirNum(std::string parentDir);
// return the number of son entry, not including hidden file or dir

char* wxString2char(wxString input_str);
//this function will return a malloc string

int getPathStatus(std::string *filename);
// return -1 exist but not file nor directory,
// 0 if path doesn't exist, 1 if path is a directory
// 2 if path is a file

bool hasContent(std::string file_path);
//given a file path, if it has content return true

char* str2char(std::string str);
//change from str to char, returned char is stored in heap

std::vector<std::string> &split(const std::string &s, char delim, std::vector<std::string> &elems);
std::vector<std::string> split(const std::string &s, char delim);

std::string getFullGlbPref();
//get the intact path of global preference
#endif
