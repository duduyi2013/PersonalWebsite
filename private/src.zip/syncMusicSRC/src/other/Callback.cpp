//
//  Callback.cpp
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#include "audio_player.h"

extern Phase_vocoder* pv;
extern GlbPara glbpara;
extern PrjPara prjpara;
extern PlayerPara playerpara;

extern Audio_buffer buffer;
extern LinearFunction cur_linear, update_linear, new_linear;
extern SF_INFO	sfinfo;
extern Network network;
extern RefMedMap* final_rmm;



int playCallback(const void *inputBuffer, void *outputBuffer,
                        unsigned long framesPerBuffer,
                        const PaStreamCallbackTimeInfo *timeInfo,
                        PaStreamCallbackFlags statusFlags,
                        void *userData){
    //portaudio callback function, details in portaudio documentation
    if (prjpara.mode == MODE_CONDUCTOR) {
        float cur_time;
        float cur_ref = GetCurRef(cur_time);
        
        if (new_linear.isStart()) {
            cur_linear.SetLinear(new_linear);
            new_linear.Reset();
            playerpara.OnConvergence = true;
        }
        if (playerpara.OnConvergence) {
            if (!cur_linear.isEqualTo(update_linear)) {
                double x = cur_linear.GetIntersectX(update_linear);
                if ( x - cur_time <= EQUAL_RANGE && cur_time - x <= EQUAL_RANGE) {
                    cur_linear.SetLinear(update_linear);
                    playerpara.OnConvergence = false;
                }
            }
        }
        if (cur_ref >= 0 && cur_ref < START_OFFSET && glbpara.audio_state != AUDIO_STOP) {
            // >=0,< here represent the start point, this condition should
            // be only executed when ref == 0, rather than ref >= 0
            glbpara.audio_state = AUDIO_PLAY;
        }
        if (!final_rmm->IsNull()) {
            if (final_rmm->Ref2Media(cur_ref) == -1) {
                if (final_rmm->GetIndexOfRef(cur_ref) < final_rmm->mapping_num - 1) {
                    playerpara.ref_state = AUDIO_IDLE;
                    playerpara.gapFlag = false;
                    
                } else {
                    playerpara.end_flag = true;
                    return paComplete;
                }
            } else {
                playerpara.ref_state = AUDIO_PLAY;
            }
        }
    } else if (prjpara.mode == MODE_TEMPO_TRACK) {
        //get current tempo
        if (!prjpara.stableTempo) {
            if (!final_rmm->IsNull()) {
                float playingTime = (float)(playerpara.player_start_samplen + playerpara.sgmtMap.getY(playerpara.output_frame_count)) / sfinfo.samplerate;
                playerpara.originCurTempo = GetOriginCurTempo(playingTime, *final_rmm);
                prjpara.tempo = playerpara.originCurTempo * prjpara.tempo_scale;
            } else {
                float playingTime = (float)(playerpara.first_frame + playerpara.sgmtMap.getY(playerpara.output_frame_count)) / sfinfo.samplerate;
                int tempTrackIndex = Time2Beats(playingTime, 1);
                playerpara.originCurTempo = (prjpara.label_index_beats[tempTrackIndex + 1] - prjpara.label_index_beats[tempTrackIndex]) / (prjpara.label_start_time[tempTrackIndex + 1] - prjpara.label_start_time[tempTrackIndex]) * 60;
                prjpara.tempo = playerpara.originCurTempo * prjpara.tempo_scale;
            }
        }
    }
    
    //fade-in/out mark
    if (prjpara.mode != MODE_LABEL && !final_rmm->IsNull()) {
        if (prjpara.mode == MODE_CONDUCTOR) {
            float cur_time;
            float cur_ref = GetCurRef(cur_time);
            if (final_rmm->timelen_eachgap[playerpara.indexofgap] - final_rmm->GetTmSpan(cur_ref) <= DAMP_DUR && !playerpara.gapFlag) {
                playerpara.indexofgap++;
                playerpara.gapFlag = true;
            }
        } else {
            long cur_count = playerpara.sgmtMap.getY(playerpara.output_frame_count);
            float cur_origin_time = (float)(playerpara.player_start_samplen + cur_count) / sfinfo.samplerate;
            if (final_rmm->timelen_eachgap[playerpara.indexofgap] - cur_origin_time <= DAMP_DUR && !playerpara.gapFlag) {
                playerpara.indexofgap++;
                playerpara.gapFlag = true;
            }
            if (playerpara.gapFlag && final_rmm->timelen_eachgap[playerpara.indexofgap - 1] <= cur_origin_time) {
                playerpara.gapFlag = false;
            }
        }
        
    }
    
    float *out = (float*)outputBuffer;
    int channels = sfinfo.channels;
    (void) inputBuffer; //paCallback basic initialization
    if (glbpara.audio_state == AUDIO_IDLE) {
        memset(out, 0, framesPerBuffer * channels * sizeof(float));//multi-channels
        return paContinue;
    } else if (glbpara.audio_state == AUDIO_PLAY) {
        if (playerpara.ref_state == AUDIO_PLAY) {
            for (int i = 0; i < channels; i++) {
                playerpara.play_data_each[i] = pv_get_output2(pv[i]);
            }
            static float damp_factor = 1.0f;
            // sync clicking
            if (prjpara.mode == MODE_LABEL && !glbpara.rcd && playerpara.index_label < prjpara.label_length) {
                long target_input_pos = prjpara.label_start_time[playerpara.index_label] * sfinfo.samplerate;
                long target_output_pos = playerpara.sgmtMap.getX(target_input_pos - prjpara.pv_fft_size / 2);
                // has to minus the offset of input count, cuz it starts not from the center of fft_size, it starts from 0
                if (target_output_pos > playerpara.output_frame_count &&
                    target_output_pos <= playerpara.output_frame_count + framesPerBuffer) {
                    playerpara.isClicking = true;
                    playerpara.index_label++;
                    playerpara.click_offset = target_output_pos - playerpara.output_frame_count - 1;
                }
            }
            
            bool is_fading;
            if ((double)(playerpara.frame_lenth - buffer.get_sample_count() / channels) / sfinfo.samplerate <= DAMP_DUR || playerpara.gapFlag) {
                is_fading = true;
            } else {
                is_fading = false;
                damp_factor = 1.0f;
            }
            float click;
            for (int i = 0; i < framesPerBuffer; i++) {
                click = 0;
                if (playerpara.isClicking) {
                    if (i >= playerpara.click_offset) {
                        click = prjpara.click_buff[playerpara.sync_pos++];
                        if (playerpara.sync_pos == prjpara.click_length) {
                            playerpara.isClicking = false;
                            playerpara.sync_pos = 0;
                        }
                    }
                }
                for (int j = 0; j < channels; j++) {
                    out[j + i * channels] = (playerpara.play_data_each[j][i] + click) * damp_factor;
                }
                if (is_fading) {
                    damp_factor -= (float)1 / (sfinfo.samplerate * DAMP_DUR);
                    if (damp_factor < 0) {
                        damp_factor = 0;
                    }
                }
                playerpara.output_frame_count++;
            }
            playerpara.click_offset = 0;
            
            if (buffer.get_sample_count() / channels >= playerpara.frame_lenth) {//multi-channels
                playerpara.end_flag = true;
                return paComplete;
            } 
            return paContinue;
        } else if (playerpara.ref_state == AUDIO_IDLE) {
            memset(out, 0, framesPerBuffer * sizeof(float) * channels);//multi-channels
            return paContinue;
        }
    } else if (glbpara.audio_state == AUDIO_STOP) {
        playerpara.end_flag = true;
        return paComplete;
    } else {
        glbpara.err_reminder = ERR_WEIRD_AUDIO_STATE;
        return paComplete;
    }
}

int test_callback(long out_count, float *samples, int len, void *rock){
    Rock *prev = (Rock *) rock;
    int my_index = prev->getIndex();
    prev->indexStep();
    
    int channels = sfinfo.channels;
    double in_count;
    if (my_index == 0) {
        if (prjpara.mode == MODE_CONDUCTOR) {
            float cur_time;//test
            float cur_ref_beat = GetCurRef(cur_time);
            //test_cur_beat = cur_ref_beat;//test
            //test_cur_time = cur_time;//test
            //add media mapping
            if (final_rmm->IsNull()) {
                in_count = beatsToTime(cur_ref_beat) * sfinfo.samplerate - playerpara.first_frame;//multi-channels
            } else {
                in_count = final_rmm->GetTmSpan(cur_ref_beat) * sfinfo.samplerate
                            - (final_rmm->total_time * sfinfo.samplerate - playerpara.frame_lenth);//multi-channels
            }
        } else {
            in_count = prev->getLastIn() + (double)prjpara.tempo_scale * (out_count - prev->getLastOut());
        }
        //test_incount = in_count;
        // in this test program, rock points to previous_input_count. It
        // should also point to the input buffer:
        int hopsize = (int)(in_count - prev->getLastIn());
        if (prjpara.mode != MODE_CONDUCTOR && (prjpara.tempo_scale != prev->getCurTempo() || playerpara.pv_callback_count == 0)){
            playerpara.sgmtMap.update(prev->getLastOut(), prev->getLastIn(), prjpara.tempo_scale);
        }
        prev->setLast(in_count, out_count, hopsize, prjpara.tempo_scale);
        if (my_index == 0) {
            buffer.took(hopsize * channels); // advance to the desired input frame
        }
    }
    float *input_data = buffer.get_read_ptr();
    long n = buffer.get_remainder() / channels;
    if (n < len) {
        int i;
        for (i = 0; i < n; i++) {
            samples[i] = input_data[i * channels + my_index];
        }
        float *next_buf = buffer.next_buffer();
        for (; i < len; i++) {
            samples[i] = next_buf[(i - n) * channels + my_index];
        }
        //memcpy(samples, input_data, n * sizeof(*samples));
        //memcpy(samples + n, buffer.next_buffer(), (len - n) * sizeof(*samples));
    } else {
        for (int i = 0; i < len; i++) {
            samples[i] = input_data[i * channels + my_index];
        }
        //memcpy(samples, input_data, len * sizeof(*samples));
    }
    playerpara.pv_callback_count++;
    return prev->getCurHopSize();
}