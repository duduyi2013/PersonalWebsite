//
//  Callback.h
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#ifndef __AudioPlayer__Callback__
#define __AudioPlayer__Callback__

#ifndef _portaudio_player_h_
#define _portaudio_player_h_
#include "portaudio.h"
#endif

int playCallback( const void *inputBuffer, void *outputBuffer,
                        unsigned long framesPerBuffer,
                        const PaStreamCallbackTimeInfo* timeInfo,
                        PaStreamCallbackFlags statusFlags,
                        void *userData );


int test_callback(long out_count, float *samples, int len, void *rock);

#endif /* defined(__AudioPlayer__Callback__) */
