//
//  audioplayerutils.cpp
//  AudioPlayer
//
//  Created by Joe on 6/22/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#include "audio_player.h"
extern GlbPara glbpara;

char* wxString2char(wxString input_str) {//this function will return a malloc string
    wxCharBuffer buffer = input_str.ToUTF8();//add necessary for music path?
    char *infile_name = (char *) malloc(sizeof(char) * (input_str.Length() + 1));//add necessary for music path?
    strcpy(infile_name,buffer.data());
    return infile_name;
}

int getSonDirNum(std::string parentDir) {
    DIR *dir;
    int sonNum = 0;
    struct dirent *entry;
    if ((dir = opendir (parentDir.c_str())) != NULL) {
        while ((entry = readdir (dir)) != NULL) {
            if (entry->d_name[0] == '.') {
                continue;
            } else {
                sonNum++;
            }
        }
        closedir(dir);
    }
    return sonNum;
}

bool hasContent(std::string file_path) {
    std::ifstream fptr;
    int length;
    fptr.open(file_path.c_str(), std::ios::binary);
    fptr.seekg(0, std::ios::end);
    length = fptr.tellg();
    fptr.close();
    if (length == 0) {
        return false;
    } else {
        return true;
    }
}

char* str2char(std::string str) {
    int i, len = str.size();
    char *chr;
    chr = (char*)malloc(sizeof(char) * (len + 1));
    for (i = 0; i < len; i++) {
        chr[i] = str[i];
    }
    chr[i] = 0;
    return chr;
}

void audCpfile(const char *src,const char *des) {
    std::ifstream srcf(src, std::ios::binary);
    std::ofstream desf(des, std::ios::binary);
    desf << srcf.rdbuf();
    srcf.close();
    desf.close();
}

std::string getFullGlbPref() {
    const char* homedir;
    if ((homedir = getenv("HOME")) == NULL) {
        homedir = getpwuid(getuid())->pw_dir;
    }
    return (std::string)homedir + "/Library/Application Support/" + glbpara.glb_pref_name;
}


int getPathStatus(std::string *filename) {
    struct stat st;
    if (stat(filename->c_str(), &st) == 0) {
        if (st.st_mode & S_IFDIR) {
            return APPATH_DIR;
        } else if (st.st_mode & S_IFREG) {
            return APPATH_FILE;
        } else {
            return APPATH_ERR;
        }
    } else {
        return APPATH_NOT_EXIST;
    }
}

std::vector<std::string> &split(const std::string &s, char delim, std::vector<std::string> &elems) {
    std::stringstream ss(s);
    std::string item;
    while (std::getline(ss, item, delim)) {
        elems.push_back(item);
    }
    return elems;
}

std::vector<std::string> split(const std::string &s, char delim) {
    std::vector<std::string> elems;
    split(s, delim, elems);
    return elems;
}
