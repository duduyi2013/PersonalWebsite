//
//  BasicClass.cpp
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#include "audio_player.h"

extern PrjPara prjpara;
extern SF_INFO sfinfo;

//******************************************
//class buffer definition
//******************************************

Audio_buffer::Audio_buffer() {
    samps_per_block = 0;
    data = NULL;
    input_data = NULL;
    cur_buff = 0;
    next_buff = 0;
    sample_count = 0;
}

void Audio_buffer::Initialize(long read_block_float) {
    samps_per_block = read_block_float;
    data = (float *) malloc(samps_per_block * 2 * sizeof(float));
    input_data = data;
    cur_buff = 0;
    next_buff = 0;
    sample_count = 0;
    assert(data);
}

Audio_buffer::~Audio_buffer() {
    free(data);
}

long Audio_buffer::get_samps_per_block() { return samps_per_block; }

float* Audio_buffer::get_read_ptr() { return input_data; }

long Audio_buffer::get_sample_count() { return sample_count; }

long Audio_buffer::get_remainder() { // how many samps can we read?
    float *end = data + (cur_buff + 1) * samps_per_block;
    return end - input_data;
}

void Audio_buffer::took(long n) {
    long remainder = get_remainder();
    if (remainder <= n) {
        cur_buff = 1 - cur_buff;
        input_data = data + cur_buff * samps_per_block;
        input_data -= remainder;
    }
    input_data += n;
    sample_count += n;
}

float* Audio_buffer::ready_for_more() {
    if (next_buff != cur_buff) {
        return data + next_buff * samps_per_block;
    }
    return NULL;
}

bool Audio_buffer::isValid() {
    return data? true : false;
}

void Audio_buffer::resetClass() {
    if (data) {
        free(data);
        data = NULL;
    }
    samps_per_block = 0;
    input_data = NULL;
    cur_buff = 0;
    next_buff = 0;
    sample_count = 0;
    
}

void Audio_buffer::write_completed() {
    next_buff = 1 - next_buff; // flip 0->1, 1->0
}

void Audio_buffer::resetBuffer() {
    input_data = data;
    cur_buff = 0;
    next_buff = 0;
    sample_count = 0;
}

float* Audio_buffer::next_buffer() {
    return data + (1 - cur_buff) * samps_per_block;
}

//******************************************
//class Rock definition
//******************************************

Rock::Rock(double last_in, double last_out, long hopSize, double tmp_scale) {
    last_in_count = last_in;
    last_out_count = last_out;
    hop_size = hopSize;
    cur_tempo_scale = tmp_scale;
    num_channels = 0;
    cur_index = 0;
}

void Rock::setChannels(int channels) {
    num_channels = channels;
}

void Rock::indexStep() {
    cur_index++;
    cur_index = cur_index % num_channels;
}

int Rock::getChannels() {
    return num_channels;
}

int Rock::getIndex() {
    return cur_index;
}

void Rock::setLast(double last_in, double last_out, long hopSize, double tmp_scale) {
    last_in_count = last_in;
    last_out_count = last_out;
    hop_size = hopSize;
    cur_tempo_scale = tmp_scale;
}
double Rock::getLastIn() {
    return last_in_count;
}
double Rock::getLastOut() {
    return last_out_count;
}
double Rock::getCurTempo() {
    return cur_tempo_scale;
}
long Rock::getCurHopSize() {
    return hop_size;
}

void Rock::reset() {
    last_out_count = prjpara.pv_fft_size / 2;
    last_in_count = 0;
    hop_size = 0;
    cur_tempo_scale = 1;
    num_channels = 0;
    cur_index = 0;
}


//******************************************
//class Linear Function
//******************************************

LinearFunction::LinearFunction() {
    x_start = LINEAR_INI_VALUE;
    y_start = LINEAR_INI_VALUE;
    slope = LINEAR_INI_VALUE;
}
LinearFunction::LinearFunction(double x, double y, double new_slope) {
    x_start = x;
    y_start = y;
    slope = new_slope;
}
bool LinearFunction::isStart() {
    if(x_start == LINEAR_INI_VALUE && y_start == LINEAR_INI_VALUE && slope == LINEAR_INI_VALUE) {
        return false;
    } else {
        return true;
    }
}

bool LinearFunction::isEqualTo(LinearFunction& target) {
    if (slope == target.slope) {
        if (x_start == target.x_start && y_start == target.y_start) {
            return true;
            //in case two functions' x and y are equal, which we cannot calculate the slope
        } else if ( (target.y_start - y_start) / (target.x_start - x_start) == target.slope){
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

float LinearFunction::GetIntersectX(LinearFunction& target) {
    return (target.y_start - y_start + slope * x_start - target.slope * target.x_start) / (slope - target.slope);
}
float LinearFunction::GetIntersectY(LinearFunction& target) {
    double x = GetIntersectX(target);
    return getY(x);
}

void LinearFunction::Reset() {
    x_start = LINEAR_INI_VALUE;
    y_start = LINEAR_INI_VALUE;
    slope = LINEAR_INI_VALUE;
}

void LinearFunction::SetLinear(LinearFunction& new_one) {
    new_one.Get(x_start, y_start, slope);
}

double LinearFunction::getY(double x) {
    return slope * (x - x_start) + y_start;
}

double LinearFunction::getX(double y) {
    return (y - y_start) / slope + x_start;
}
void LinearFunction::Set(double x, double y, double new_slope) {
    x_start = x;
    y_start = y;
    slope = new_slope;
}
void LinearFunction::Get(double &x, double &y, double &s) {
    x = x_start;
    y = y_start;
    s = slope;
}

//******************************************
//class Reference-Media Mapping 
//******************************************
RefMedMap::RefMedMap() {
    ref_beat = NULL;
    med_beat = NULL;
    duration = NULL;
    time_gap = NULL;
    total_time = 0;
    mapping_num = 0;
    cur_read_ref_beat = 0;
    cur_read_ref_index = 0;
}

RefMedMap::RefMedMap(int num) {
    ref_beat = new float[num];
    med_beat = new float[num];
    duration = new float[num];
    time_gap = new float[num];
    total_time = 0;
    mapping_num = num;
    cur_read_ref_beat = 0;
    cur_read_ref_index = 0;
}

RefMedMap::~RefMedMap() {
    if (ref_beat) {
        delete[] ref_beat;
        ref_beat = NULL;
    }
    if (med_beat) {
        delete[] med_beat;
        med_beat = NULL;
    }
    if (duration) {
        delete[] duration;
        duration = NULL;
    }
    if (time_gap) {
        delete[] time_gap;
        time_gap = NULL;
    }
    timelen_eachgap.clear();
}

void RefMedMap::Reset() {
    
    if (ref_beat) {
        delete[] ref_beat;
        ref_beat = NULL;
    }
    if (med_beat) {
        delete[] med_beat;
        med_beat = NULL;
    }
    if (duration) {
        delete[] duration;
        duration = NULL;
    }
    if (time_gap) {
        delete[] time_gap;
        time_gap = NULL;
    }
    
    timelen_eachgap.clear();
    total_time = 0;
    mapping_num = 0;
    cur_read_ref_beat = 0;
    cur_read_ref_index = 0;
}

void RefMedMap::SetAllocate(int num) {
    ref_beat = new float[num];
    med_beat = new float[num];
    duration = new float[num];
    time_gap = new float[num];
    mapping_num = num;
}

void RefMedMap::FillEntriesFromSheet(std::vector<std::string> sheet) {
    int i;
    for (i = 0 ; i < mapping_num ; i++) {
        std::vector<std::string> tokens = split(sheet[i], ' ');
        ref_beat[i] = std::atof(tokens[0].c_str());
        med_beat[i] = std::atof(tokens[1].c_str());
        duration[i] = std::atof(tokens[2].c_str());
        time_gap[i] = beatsToTime(med_beat[i] + duration[i])
        - beatsToTime(med_beat[i]);
        if (i > 0 && ref_beat[i] > ref_beat[i - 1] + duration[i - 1]) {
            timelen_eachgap.push_back(total_time);
        }
        total_time += time_gap[i];
    }
    timelen_eachgap.push_back(total_time);
}

void RefMedMap::RestartMusc() {
    cur_read_ref_beat = 0;
    cur_read_ref_index = 0;
}

bool RefMedMap::IsNull() {
    if (ref_beat&&med_beat&&duration) {
        return false;
    } else {
        return true;
    }
}

float RefMedMap::Ref2Media(float ref) {
    int i = GetIndexOfRef(ref);
    if (i == -1) {
        return -1;
    } else {
        if (ref_beat[i] <= ref && ref <= ref_beat[i] + duration[i]) {
            return med_beat[i] + ref - ref_beat[i];
        } else {    
            return -1;
        }
    }
}

float RefMedMap::GetTmSpan(float refbeat) {
    int i;
    float time_span = 0;
    for (i = 0; i < mapping_num; i++) {
        if (ref_beat[i] <= refbeat) {
            if (refbeat <= ref_beat[i] + duration[i]) {
                time_span += beatsToTime(Ref2Media(refbeat)) - beatsToTime(med_beat[i]);
                return time_span;
            }
        } else if (i == 0) {
            return time_span;
        } else {
            return time_span;
        }
        time_span += time_gap[i];
    }
    return time_span;
}

float RefMedMap::GetRemainFrameCount() {
    int i = cur_read_ref_index;
    float cur_read_med_beat = Ref2Media(cur_read_ref_beat);
    if (cur_read_med_beat != -1) {
        float remain_time = beatsToTime(med_beat[i] + duration[i])
                            - beatsToTime(cur_read_med_beat);
        return remain_time * sfinfo.samplerate;//multi-channels
    } else {
        return 0;
    }
}

int RefMedMap::GetIndexOfRef(float ref_b) {
    int i;
    for (i = 0; i < mapping_num ; i++) {
        if (ref_beat[i] <= ref_b) {
            if (ref_b < ref_beat[i] + duration[i]) {
                return i;
            }
        } else {
            return i - 1;
        }
    }
    return i - 1;
}

//************************************************************************************
//class performance beat to reference beat map struct
//************************************************************************************

PerfRefMap::PerfRefMap() {
    ref_beat = NULL;
    duration = NULL;
    my_pmm = NULL;
    mapping_num = 0;
}

PerfRefMap::~PerfRefMap() {
    if (ref_beat) {
        delete[] ref_beat;
        ref_beat = NULL;
    }
    if (duration) {
        delete[] duration;
        duration = NULL;
    }
    if (my_pmm) {
        delete my_pmm;
        my_pmm = NULL;
    }
}

void PerfRefMap::SetAllocate(int num) {
    ref_beat = new float[num];
    duration = new float[num];
    mapping_num = num;
}

bool PerfRefMap::IsNull() {
    if (ref_beat && duration && mapping_num > 0) {
        return false;
    } else {
        return true;
    }
}

void PerfRefMap::Reset() {
    if (ref_beat) {
        delete[] ref_beat;
        ref_beat = NULL;
    }
    if (duration) {
        delete[] duration;
        duration = NULL;
    }
    if (my_pmm) {
        delete my_pmm;
        my_pmm = NULL;
    }
    mapping_num = 0;
}

RefMedMap* PerfRefMap::SetPMM(RefMedMap& origin) {
    if (IsNull()) {
        std::cout << "Cannot convert to refmedmap, because there is no perfrefmap" << std::endl;
        if (my_pmm) {
            delete my_pmm;
            my_pmm = NULL;
        }
        return NULL;
    } else {
        RefMedMap *pmm = new RefMedMap();
        if (origin.IsNull()) {
            int i, perf_beat = 0;
            pmm->SetAllocate(mapping_num);
            for (i = 0; i < mapping_num; i++) {
                pmm->ref_beat[i] = perf_beat;
                pmm->med_beat[i] = ref_beat[i];
                pmm->duration[i] = duration[i];
                pmm->time_gap[i] = beatsToTime(ref_beat[i] + duration[i])
                                       - beatsToTime(ref_beat[i]);
                if (i > 0 && pmm->ref_beat[i] > pmm->ref_beat[i - 1] + pmm->duration[i - 1]) {
                    pmm->timelen_eachgap.push_back(pmm->total_time);
                }
                pmm->total_time += pmm->time_gap[i];
                perf_beat += duration[i];
            }
            pmm->timelen_eachgap.push_back(pmm->total_time);
            pmm->cur_read_ref_beat = pmm->ref_beat[0];
            //since conductor always starts from performance beat 0
        } else {
            int i;
            std::vector<float> new_perf_beat;
            std::vector<float> new_ref_beat;
            std::vector<float> new_duration;
            float perf_beat = 0;
//            static int wgqi = 0;
//            wgqi++;
//            if (wgqi == 2) {
//                wgqi = wgqi;
//            }
            for (i = 0; i < mapping_num; i++) {
                float end_ref = ref_beat[i] + duration[i];
                int start_index = origin.GetIndexOfRef(ref_beat[i]);
                int end_index = origin.GetIndexOfRef(end_ref);
                float startdur_end_ref = origin.ref_beat[start_index] + origin.duration[start_index];
                float enddur_end_ref = origin.ref_beat[end_index] + origin.duration[end_index];
                int j;
                for (j = start_index; j  <= end_index; j++) {
                    if (j == start_index) {
                        if (start_index != -1) {
                            float first_end = startdur_end_ref;
                            if (start_index == end_index && end_ref < enddur_end_ref) {
                                first_end = end_ref;
                                // in case there is only one duration within an entry
                            }
                            if (ref_beat[i] < startdur_end_ref) {
                                new_perf_beat.push_back(perf_beat);
                                new_ref_beat.push_back(ref_beat[i]);
                                new_duration.push_back(first_end - ref_beat[i]);
                            }
                        } else {
                            continue;
                        }
                    } else if (j == end_index) {
                        if (end_ref != origin.ref_beat[end_index]) {
                            float cur_perf_beat = origin.ref_beat[end_index] - ref_beat[i] + perf_beat;
                            if (end_ref >= enddur_end_ref) {
                                new_perf_beat.push_back(cur_perf_beat);
                                new_ref_beat.push_back(origin.ref_beat[end_index]);
                                new_duration.push_back(origin.duration[end_index]);
                            } else {
                                new_perf_beat.push_back(cur_perf_beat);
                                new_ref_beat.push_back(origin.ref_beat[end_index]);
                                new_duration.push_back(end_ref - origin.ref_beat[end_index]);
                            }
                        }
                    } else {
                        float cur_perf_beat = origin.ref_beat[j] - ref_beat[i] + perf_beat;
                        new_perf_beat.push_back(cur_perf_beat);
                        new_ref_beat.push_back(origin.ref_beat[j]);
                        new_duration.push_back(origin.duration[j]);
                    }
                }
                perf_beat += duration[i];
            }
            
//            if (wgqi == 2) {
//                wgqi = wgqi;
//            }
            pmm->SetAllocate(new_perf_beat.size());
            for (i = 0; i < new_perf_beat.size(); i++) {
                pmm->ref_beat[i] = new_perf_beat[i];
                pmm->med_beat[i] = origin.Ref2Media(new_ref_beat[i]);
                pmm->duration[i] = new_duration[i];
                pmm->time_gap[i] = beatsToTime(pmm->ref_beat[i] + pmm->duration[i])
                                       - beatsToTime(pmm->ref_beat[i]);
                if (i > 0 && pmm->ref_beat[i] > pmm->ref_beat[i - 1] + pmm->duration[i - 1]) {
                    pmm->timelen_eachgap.push_back(pmm->total_time);
                }
                pmm->total_time += pmm->time_gap[i];
            }
            
//            if (wgqi == 2) {
//                wgqi = wgqi;
//            }
            pmm->timelen_eachgap.push_back(pmm->total_time);
            pmm->cur_read_ref_beat = pmm->ref_beat[0];
        }
        if (my_pmm) {
            delete my_pmm;
        }
        my_pmm = pmm;
        int i;
        printf("New Media Map:\n");
        for (i = 0; i < pmm->mapping_num; i++) {
            printf("%lf , %lf , %lf\n",pmm->ref_beat[i], pmm->med_beat[i], pmm->duration[i]);
        }
        return pmm;
    }
}

//************************************************************************************
//class SegmentalMapping struct
//************************************************************************************


SegmentalMapping::SegmentalMapping(){
    xs = NULL;
    ys = NULL;
    slopes = NULL;
    mysize = 0;
    filledCount = 0;
}

SegmentalMapping::SegmentalMapping(long size){
    xs = (float *)malloc(sizeof(float) * size);
    ys = (float *)malloc(sizeof(float) * size);
    slopes = (float *)malloc(sizeof(float) * size);
    mysize = size;
    filledCount = 0;
}

void SegmentalMapping::reset(){
    if (xs) {
        free(xs);
        xs = NULL;
    }
    if (ys) {
        free(ys);
        ys = NULL;
    }
    if (slopes) {
        free(slopes);
        slopes = NULL;
    }
    mysize = 0;
    filledCount = 0;
}

void SegmentalMapping::allocate(long size) {
    xs = (float *)malloc(sizeof(float) * size);
    ys = (float *)malloc(sizeof(float) * size);
    slopes = (float *)malloc(sizeof(float) * size);
    mysize = size;
    filledCount = 0;
    memset(slopes, 0, sizeof(float) * size);
}

float SegmentalMapping::getX(float y){
    int index;
    for (index = 0; index < filledCount; index++) {
        if (ys[index] >= y) {
            if (index == 0) {
                index++;
            }
            float x0 = xs[index - 1];
            float y0 = ys[index - 1];
            float slope = slopes[index - 1];

            return x0 - (y0 - y) / slope;
        }
    }
    return xs[index - 1] - (ys[index - 1] - y) / slopes[index - 1];
}

float SegmentalMapping::getY(float x){
    int index;
    for (index = 0; index < filledCount; index++) {
        if (xs[index] >= x) {
            if (index == 0) {
                index++;
            }
            float x0 = xs[index - 1];
            float y0 = ys[index - 1];
            float slope = slopes[index - 1];
            
            return y0 - (x0 - x) * slope;
        }
    }
    return ys[index - 1] - (xs[index - 1] - x) * slopes[index - 1];
}

void SegmentalMapping::update(float x, float y, float slope) {
    if (filledCount < mysize) {
        xs[filledCount] = x;
        ys[filledCount] = y;
        slopes[filledCount] = slope;
        filledCount++;
    } else {
        int i;
        for (i = 0; i < mysize - 1; i++) {
            xs[i] = xs[i + 1];
            ys[i] = ys[i + 1];
            slopes[i] = slopes[i + 1];
        }
        xs[i] = x;
        ys[i] = y;
        slopes[i] = slope;
    }
}

//************************************************************************************
//class Glb preference file struct
//************************************************************************************

GlbPara::GlbPara() {
    rcd = true;
    read_per_time = READ_BLOCK / sizeof(float);
    audio_state = AUDIO_STOP;
    err_reminder = 0;
    connect_flag = false;
    framePerBuffer = 0;
    
    ArngName = "";
    DeviceName = "";
    glb_pref_name = "HCMP/APprefs.txt";
    
    music_path = NULL;
    prj_name = NULL;
    aud_name = NULL;
}

//************************************************************************************
//class Prj preference file struct
//************************************************************************************

PrjPara::PrjPara() {
    stableTempo = true;
    read_per_time = 0;
    
    tapping_num = 0;
    
    click_buff = (float*)malloc(CLICK_BUFF_SIZE);
    click_length = 0;
    
    wav_file = "";
    lab_file = "";
    pref_file = "";
    rmm_file = "";
    click_file = "";
    
    label_length = 0;
    label_start_time = NULL;
    label_stop_time = NULL;
    label_index_beats = NULL;
    
    start_beat = DEFAULT_START_BEAT;
    end_beat = DEFAULT_END_BEAT;
    arrag = DEFAULT_ARRAGEMENT;
    mode = DEFAULT_MODE;
    tempo_scale = 1.0f;
    tempo = DEFAULT_TEMPO;
    volume = DEFAULT_VOLUME;
    pv_fft_size = DEFAULT_FFTSIZE;
    pv_hop_size = DEFAULT_HOPSIZE;
    fixed_tempo = DEFAULT_FIXED_TEMPO;
    fixed_tempo_starttime = DEFAULT_START_TIME;
    first_beat = DEFAULT_FIRST_BEAT;
    beat_step = DEFAULT_BEAT_STEP;
    beat_offset = DEFAULT_BEAT_OFFSET;
};

void PrjPara::reset() {
    tapping_timing.clear();
    tapping_num = 0;
    
    stableTempo = true;
    read_per_time = 0;
    
    memset(click_buff, 0, CLICK_BUFF_SIZE);
    click_length = 0;
    
    label_length = 0;
    if(label_start_time != NULL) {
        delete[] label_start_time;
        label_start_time = NULL;
    }
    if(label_stop_time != NULL) {
        delete[] label_stop_time;
        label_stop_time = NULL;
    }
    if(label_index_beats != NULL) {
        delete[] label_index_beats;
        label_index_beats = NULL;
    }
    wav_file.clear();
    lab_file.clear();
    pref_file.clear();
    rmm_file.clear();
    click_file.clear();
    
    start_beat = DEFAULT_START_BEAT;
    end_beat = DEFAULT_END_BEAT;
    arrag = DEFAULT_ARRAGEMENT;
    mode = DEFAULT_MODE;
    tempo_scale = 1.0f;
    tempo = DEFAULT_TEMPO;
    volume = DEFAULT_VOLUME;
    pv_fft_size = DEFAULT_FFTSIZE;
    pv_hop_size = DEFAULT_HOPSIZE;
    fixed_tempo = DEFAULT_FIXED_TEMPO;
    fixed_tempo_starttime = DEFAULT_START_TIME;
    first_beat = DEFAULT_FIRST_BEAT;
    beat_step = DEFAULT_BEAT_STEP;
    beat_offset = DEFAULT_BEAT_OFFSET;
}

//************************************************************************************
//class player preference struct
//************************************************************************************

PlayerPara::PlayerPara() {
    pv_callback_count = 0;
    click_offset = 0;
    index_label = 0;
    isClicking = false;
    sync_pos = 0;
    output_frame_count = 0;
    originCurTempo = 0;
    ref_state = AUDIO_PLAY;
    readcount = 0;
	last_sample = 0;
	first_frame = 0;
    player_start_samplen = 0;
    indexofgap = 0;
    gapFlag = false;
    audio_file_has_data = true;
    
    OnConvergence = false;
    play_data_each = NULL;
    end_flag = false;
    frame_lenth = 0;
}

void PlayerPara::reset() {
    pv_callback_count = 0;
    sgmtMap.reset();
    click_offset = 0;
    index_label = 0;
    isClicking = false;
    sync_pos = 0;
    output_frame_count = 0;
    ref_state = AUDIO_PLAY;
    readcount = 0;
	last_sample = 0;
	first_frame = 0;
    player_start_samplen = 0;
    indexofgap = 0;
    gapFlag = false;
    audio_file_has_data = true;
    
    OnConvergence = false;
    if (play_data_each) {
        free(play_data_each);
        play_data_each = NULL;
    }
    end_flag = false;
    frame_lenth = 0;
}