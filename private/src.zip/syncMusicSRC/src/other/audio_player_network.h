//
//  audio_player_network.h
//  AudioPlayer
//
//  Created by Joe on 6/12/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#ifndef AudioPlayer_audio_player_network_h
#define AudioPlayer_audio_player_network_h
#include <string>
#include "zmq.hpp"

class Network{
    long id_num;
    std::string player_num;
    double mapping_offset;
    struct timeval last_time;
    float minimal_latency;
    
    zmq::context_t *context;
    zmq::socket_t *sub_socket;
    zmq::socket_t *push_socket;
public:
    Network();
    void Connect(std::string ip, std::string push_port, std::string sub_port);
    void Disconnect();
    
    void Join();
    //add how to correctly exit
    void SendMessage(std::string message);
    void Listener();
    
    void timeSync();
    std::string getPlayerNum();
    double getOffset();
    float getLatency();
    void setLastTime();
    bool isMin(struct timeval now);
    bool HandleSyncMessage(std::vector<std::string> &token, struct timeval now);
    bool HandleIdMessage(std::vector<std::string> &token);
    void HandleLoadMessage(std::vector<std::string> &token);
    void HandlePosMessage(std::vector<std::string> &token);
    void HandleTmMessage(std::vector<std::string> &token);
    void HandlePlayMessage(std::vector<std::string> &token);
    void HandlePauseMessage(std::vector<std::string> &token);
    void HandleStopMessage(std::vector<std::string> &token);
    
    bool HandleArrangementMessage(std::vector<std::string> &token);
    
    ~Network();
};

#endif
