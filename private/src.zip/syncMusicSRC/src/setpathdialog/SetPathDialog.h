//
//  SetPathDialog.h
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#ifndef __AudioPlayer__SetPathDialog__
#define __AudioPlayer__SetPathDialog__

//set music path dialog class
//************Description***************
//this is a new dialog about setting path
//***************************

#include "wx/wx.h"

class SetPathDialog : public wxDialog{
    wxTextCtrl *wxtxt_path_text;
    wxButton *path_search;
public:
    SetPathDialog();
    ~SetPathDialog();
    void OnConfirm(wxCommandEvent &event);
    void OnChooseDir(wxCommandEvent &event);
    void ShowCurPath();
};
#endif /* defined(__AudioPlayer__SetPathDialog__) */
