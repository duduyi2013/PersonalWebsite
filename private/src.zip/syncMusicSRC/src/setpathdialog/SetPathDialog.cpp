//
//  SetPathDialog.cpp
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#include "audio_player.h"

extern GlbPara glbpara;

SetPathDialog::SetPathDialog()
:wxDialog(NULL,wxID_ANY,"Set Music Path",wxDefaultPosition,wxSize(500,150)){
    wxPanel *pan = new wxPanel(this, wxID_ANY);
    wxtxt_path_text = new wxTextCtrl(pan, wxID_ANY, "", wxDefaultPosition, wxSize(400,20));
    path_search = new wxButton(pan, ID_DIALOG_MUSIC_PATH_SEARCH, ".."
                               , wxDefaultPosition, wxSize(30,-1));
    wxButton *button_ok = new wxButton(pan, ID_DIALOG_MUSIC_PATH_OK, "OK");
    wxButton *button_cancel = new wxButton(pan, ID_DIALOG_MUSIC_PATH_CANCEL, "CANCEL");
    
    wxBoxSizer *first_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *second_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *whole = new wxBoxSizer(wxVERTICAL);
    
    first_line->Add(wxtxt_path_text, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    first_line->Add(path_search, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    second_line->Add(button_ok, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    second_line->Add(button_cancel, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole->Add(first_line, wxSizerFlags(0).Align(1).Border(wxTOP, 25));
    whole->Add(second_line, wxSizerFlags(0).Align(1).Border(wxTOP, 25));
    pan->SetSizer(whole);
    
    Connect(ID_DIALOG_MUSIC_PATH_SEARCH, wxEVT_COMMAND_BUTTON_CLICKED
            ,wxCommandEventHandler(SetPathDialog::OnChooseDir));
    SetEscapeId(ID_DIALOG_MUSIC_PATH_CANCEL);
    Connect(ID_DIALOG_MUSIC_PATH_OK, wxEVT_COMMAND_BUTTON_CLICKED
            , wxCommandEventHandler(SetPathDialog::OnConfirm));
    ShowCurPath();
}

SetPathDialog::~SetPathDialog() {
    Destroy();
}


void SetPathDialog::OnConfirm(wxCommandEvent &event) {
    if ( glbpara.music_path ) {
        free(glbpara.music_path);
        glbpara.music_path = NULL;
    }
    if (glbpara.prj_name) {
        free(glbpara.prj_name);
        glbpara.prj_name = NULL;
    }
    if (glbpara.aud_name) {
        free(glbpara.aud_name);
        glbpara.aud_name = NULL;
    }
    glbpara.music_path = wxString2char(wxtxt_path_text->GetValue());
    
    if (!updateDropdownItems(glbpara.music_path, &glbpara.project_list)) {
        free(glbpara.music_path);
        glbpara.music_path = NULL;
        return ;
    }
    std::string glb_pref_path = getFullGlbPref();
    int status = getPathStatus(&glb_pref_path);
    if (status == APPATH_NOT_EXIST) {
        std::string glb_hcmp_path = glb_pref_path.substr(0, glb_pref_path.find("APprefs.txt", 41) - 1);
        int prnt_status = getPathStatus(&glb_hcmp_path);
        if (prnt_status == APPATH_NOT_EXIST){
            mkdir(glb_hcmp_path.c_str(), S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH);
        }
    } else if (status != APPATH_FILE) {
        wxMessageDialog err(NULL, "Prefs.txt exists but not a file", "File Error", wxOK);
        err.ShowModal();
        if ( glbpara.music_path ) {
            free(glbpara.music_path);
            glbpara.music_path = NULL;
        }
        return ;
    }
    glbPrefWrite(glb_pref_path);
    EndModal(SUCCESSFUL);
}

void SetPathDialog::OnChooseDir(wxCommandEvent & WXUNUSED(event)) {
    wxDirDialog dir(NULL, "Search Music Path", wxEmptyString
                    , wxDD_DIR_MUST_EXIST);
    if (dir.ShowModal() == wxID_OK) {
        if(!wxtxt_path_text->IsEmpty()) {
            wxtxt_path_text->Clear();
        }
        wxtxt_path_text->SetValue(dir.GetPath());
    }
}

void SetPathDialog::ShowCurPath() {
    wxtxt_path_text->SetValue((wxString)glbpara.music_path);
}
