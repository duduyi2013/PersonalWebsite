//
//  ImportDialog.h
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#ifndef __AudioPlayer__ImportDialog__
#define __AudioPlayer__ImportDialog__

//import new project dialog class
//************Description***************
//this is a new dialog about importing new project
//***************************

#include "wx/wx.h"

class ImportDialog : public wxDialog{
    wxTextCtrl *wxtxt_project_name;
    wxTextCtrl *wxtxt_audio_path;
    wxButton *search_audio_path;
    wxTextCtrl *wxtxt_label_path;
    wxButton *search_label_path;
    wxTextCtrl *wxtxt_click_path;
    wxButton *search_click_path;
    wxTextCtrl *wxtxt_fixed_tempo;
    wxTextCtrl *wxtxt_id_num;
    wxTextCtrl *wxtxt_beat1_time;
    
    wxString aud_src_name;
    wxString lab_src_name;
    wxString click_src_name;
    
public:
    ImportDialog();
    ~ImportDialog();
    void OnLoadSource(wxCommandEvent &event);
    void OnConfirm(wxCommandEvent &event);
};


#endif /* defined(__AudioPlayer__ImportDialog__) */
