//
//  ImportDialog.cpp
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#include "audio_player.h"

extern GlbPara glbpara;
extern PrjPara prjpara;

ImportDialog::ImportDialog()
: wxDialog(NULL,wxID_ANY,"Import Project", wxDefaultPosition, wxSize(600, 400)) {
    wxPanel *pan = new wxPanel(this, wxID_ANY);
    
    wxStaticText *label_project_name = new wxStaticText(pan, wxID_ANY, "Project Name:");
    wxtxt_project_name = new wxTextCtrl(pan, wxID_ANY, "", wxDefaultPosition, wxSize(400,25));
    
    wxStaticText *label_audio_file = new wxStaticText(pan, wxID_ANY, "Audio File:");
    wxtxt_audio_path = new wxTextCtrl(pan, wxID_ANY, "", wxDefaultPosition, wxSize(400,25));
    search_audio_path = new wxButton(pan, ID_DIALOG_IMPORT_AUDIO_SEARCH, ".."
                                     , wxDefaultPosition, wxSize(30,-1));
    
    wxStaticText *label_label_file = new wxStaticText(pan, wxID_ANY, "Label File:");
    wxtxt_label_path = new wxTextCtrl(pan, wxID_ANY, "", wxDefaultPosition, wxSize(400,25));
    search_label_path = new wxButton(pan, ID_DIALOG_IMPORT_LABEL_SEARCH, ".."
                                     , wxDefaultPosition, wxSize(30,-1));
    
    wxStaticText *label_click_file = new wxStaticText(pan, wxID_ANY, "Click File:");
    wxtxt_click_path = new wxTextCtrl(pan, wxID_ANY, "", wxDefaultPosition, wxSize(400,25));
    search_click_path = new wxButton(pan, ID_DIALOG_IMPORT_CLICK_SEARCH, ".."
                                     , wxDefaultPosition, wxSize(30,-1));
    
    wxStaticText *label_fixed_tempo = new wxStaticText(pan, wxID_ANY, "Autolabel Tempo:");
    wxtxt_fixed_tempo = new wxTextCtrl(pan, wxID_ANY, "", wxDefaultPosition, wxSize(140,25));
    wxStaticText *label_tempo_unit = new wxStaticText(pan, wxID_ANY, "bpm");
    
    wxStaticText *label_beat1 = new wxStaticText(pan, wxID_ANY, "Beat 0 Time:");
    wxtxt_beat1_time = new wxTextCtrl(pan, wxID_ANY, "", wxDefaultPosition, wxSize(140,25));
    wxStaticText *label_beat1_time_unit = new wxStaticText(pan, wxID_ANY, "s");
    
    wxStaticText *label_id = new wxStaticText(pan, wxID_ANY, "ID:");
    wxtxt_id_num = new wxTextCtrl(pan, wxID_ANY, "1");
    
    wxButton *button_ok = new wxButton(pan, ID_DIALOG_IMPORT_OK, "OK");
    wxButton *button_cancel = new wxButton(pan, ID_DIALOG_IMPORT_CANCEL, "CANCEL");
    
    wxBoxSizer *first_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *second_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *third_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *forth_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *fifth_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *sixth_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *seventh_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *eighth_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *whole_sizer = new wxBoxSizer(wxVERTICAL);
    
    first_line->Add(label_project_name, wxSizerFlags(0).Align(1).Border(wxALL,5));
    first_line->Add(wxtxt_project_name, wxSizerFlags(0).Align(1).Border(wxALL,5));
    second_line->Add(label_audio_file, wxSizerFlags(0).Align(1).Border(wxALL,5));
    second_line->Add(wxtxt_audio_path, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    second_line->Add(search_audio_path, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    third_line->Add(label_label_file, wxSizerFlags(0).Align(1).Border(wxALL,5));
    third_line->Add(wxtxt_label_path, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    third_line->Add(search_label_path, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    forth_line->Add(label_click_file, wxSizerFlags(0).Align(1).Border(wxALL,5));
    forth_line->Add(wxtxt_click_path, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    forth_line->Add(search_click_path, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    
    fifth_line->Add(label_fixed_tempo, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    fifth_line->Add(wxtxt_fixed_tempo, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    fifth_line->Add(label_tempo_unit, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    sixth_line->Add(label_beat1, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    sixth_line->Add(wxtxt_beat1_time, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    sixth_line->Add(label_beat1_time_unit, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    seventh_line->Add(label_id, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    seventh_line->Add(wxtxt_id_num, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    eighth_line->Add(button_ok, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    eighth_line->Add(button_cancel, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(first_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(second_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(third_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(forth_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(fifth_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(sixth_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(seventh_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(eighth_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    pan->SetSizer(whole_sizer);
    
    SetEscapeId(ID_DIALOG_IMPORT_CANCEL);
    Connect(ID_DIALOG_IMPORT_OK, wxEVT_COMMAND_BUTTON_CLICKED
            , wxCommandEventHandler(ImportDialog::OnConfirm));
    Connect(ID_DIALOG_IMPORT_AUDIO_SEARCH, ID_DIALOG_IMPORT_CLICK_SEARCH
            , wxEVT_COMMAND_BUTTON_CLICKED, wxCommandEventHandler(ImportDialog::OnLoadSource));
    
}

ImportDialog::~ImportDialog() {
    Destroy();
}

void ImportDialog::OnLoadSource(wxCommandEvent &event) {
    wxFileDialog open(NULL);
    wxTextCtrl *wxtxt_mypath;
    wxString *src_name;
    if (event.GetId() == ID_DIALOG_IMPORT_AUDIO_SEARCH) {
        wxtxt_mypath = wxtxt_audio_path;
        src_name = &aud_src_name;
    } else if (event.GetId() == ID_DIALOG_IMPORT_LABEL_SEARCH) {
        wxtxt_mypath = wxtxt_label_path;
        src_name = &lab_src_name;
    } else if (event.GetId() == ID_DIALOG_IMPORT_CLICK_SEARCH) {
        wxtxt_mypath = wxtxt_click_path;
        src_name = &click_src_name;
    }
    if (open.ShowModal() == wxID_OK) {
        if (!wxtxt_mypath->IsEmpty()) {
            wxtxt_mypath->Clear();
        }
        wxtxt_mypath->SetValue(open.GetPath());
        *src_name = open.GetFilename();
    }
}

void ImportDialog::OnConfirm(wxCommandEvent &event) {
    //add some code here
    wxString wxStr_prj_name = wxtxt_project_name->GetValue();
    wxString wxStr_aud_id = wxtxt_id_num->GetValue();
    wxString wxStr_aud_name = wxtxt_audio_path->GetValue();
    wxString wxStr_label_name = wxtxt_label_path->GetValue();
    wxString wxStr_click_name = wxtxt_click_path->GetValue();
    wxString wxStr_fixed_tempo = wxtxt_fixed_tempo->GetValue();
    wxString wxStr_first_time = wxtxt_beat1_time->GetValue();
    bool is_label_exist = false, is_fixed_tempo_exist = false, is_click_exist = false;
    long id_value = 1;
    
    if (wxStr_prj_name.IsNull()) {
        wxMessageDialog err(NULL, "You need to pick a name of the project"
                            , "Name Error", wxOK);
        err.ShowModal();
        return ;
    }
    
    struct stat check_exist;
    if ( stat( wxStr_aud_name.c_str(), &check_exist ) != 0 ) {
        wxMessageDialog err(NULL, "Audio file path doesn't exist!"
                            , "Path Error", wxOK);
        err.ShowModal();
        return ;
    }
    
    if (!wxStr_click_name.IsNull() ) {
        if ( stat( wxStr_click_name.c_str(), &check_exist ) != 0) {
            wxMessageDialog err(NULL, "Click file path doesn't exist!"
                                , "Path Error", wxOK);
            err.ShowModal();
            return ;
        } else {
            is_click_exist = true;
        }
    } else {
        is_click_exist = false;
    }
    
    
    if ( stat( wxStr_label_name.c_str(), &check_exist ) != 0 ) {
        if ( !wxStr_label_name.IsNull() ) {
            wxMessageDialog err(NULL, "Invalid Label file path!"
                                , "File Error", wxOK);
            err.ShowModal();
            return ;
        } else if (wxStr_fixed_tempo.IsNull()) {
            wxMessageDialog err(NULL, "Label file path and fixed tempo don't exist"
                                , "Tempo Error", wxOK);
            err.ShowModal();
            return ;
        } else if ( !wxStr_fixed_tempo.ToDouble(&prjpara.fixed_tempo) || prjpara.fixed_tempo <= 0 ) {
            wxMessageDialog err(NULL, "Invalid Fixed Tempo"
                                , "Tempo Error", wxOK);
            err.ShowModal();
            return ;
        } else if ( !wxStr_first_time.ToDouble(&prjpara.fixed_tempo_starttime) || prjpara.fixed_tempo_starttime < 0) {
            wxMessageDialog err(NULL, "Invalid Fixed Tempo Start Time"
                                , "Start Time Error", wxOK);
            err.ShowModal();
            return ;
        } else {
            is_fixed_tempo_exist = true;
        }
    } else {
        is_label_exist = true;
    }
    if (!wxStr_aud_id.ToLong(&id_value)) {
        wxMessageDialog err(NULL, "Invalid ID Value", "Error", wxOK);
        err.ShowModal();
        return ;
    }
    
    std::string full_path = glbpara.music_path;
    glbpara.prj_name = wxString2char(wxStr_prj_name);
    glbpara.aud_name = wxString2char("audio-" + wxStr_aud_id);
    full_path = full_path + "/" + glbpara.prj_name;
    if ( mkdir(full_path.c_str(), S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH) != 0) {
        if ( mkdir((full_path + "/" + glbpara.aud_name).c_str(),
                  S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH) != 0) {
            // both the prj and aud have already existed
            // cannot creat new prj
            wxMessageDialog err(NULL, "File(" + full_path + ") already exists"
                                , "Dir Error", wxOK);
            err.ShowModal();
            free(glbpara.prj_name);
            glbpara.prj_name = NULL;
            free(glbpara.aud_name);
            glbpara.aud_name = NULL;
            return ;
        }
        if (!updateDropdownItems(full_path, &glbpara.id_list)) {
            free(glbpara.prj_name);
            glbpara.prj_name = NULL;
            free(glbpara.aud_name);
            glbpara.aud_name = NULL;
            return ;
        }
    } else {
        mkdir((full_path + "/" + glbpara.aud_name).c_str(), S_IRWXU|S_IRGRP|S_IXGRP|S_IROTH|S_IXOTH);
        glbpara.id_list.clear();
        glbpara.project_list.push_back(glbpara.prj_name);
        glbpara.id_list.push_back(glbpara.aud_name);
    }
    full_path = full_path + "/" + glbpara.aud_name;
    
    audCpfile(wxStr_aud_name.c_str(), (full_path + "/" + aud_src_name).c_str());
    if (is_click_exist) {
        audCpfile(wxStr_click_name.c_str(), (full_path + "/" + click_src_name).c_str());
    }
    if ( is_label_exist ) {
        audCpfile(wxStr_label_name.c_str(), (full_path + "/" + lab_src_name).c_str());
    }
    
    glbPrefWrite(getFullGlbPref());
    prefsWrite(full_path + "/prefs.txt",2);
    EndModal(SUCCESSFUL);
}
