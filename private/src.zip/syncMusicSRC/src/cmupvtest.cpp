// cmupvtest.cpp -- test phase vocoder

// #include <stdio.h>
// #include <stdlib.h>
// #include <time.h>
// #include <pthread.h>
//#define USE_ABSOLUTE

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <unistd.h>
#include <assert.h>
#include <math.h>

#include "pv.h"
#include "portaudio.h"
#include "sndfile.h"

#define	MAX_CHANNELS	(2)
#define BLOCK_SIZE (256)
#define READ_BLOCK (1024*1024)

#define MAX_DIGIT_BEATS 10


using namespace std;

//static float *outtt=NULL; // test
//static long int out_index=0; //test

Phase_vocoder pv;
float pv_ratio = 1; // pv ratio
// static long int output_index = 0; //output pointer index
static long int readcount = 0; //number of successfully read samples
static float *play_data; //data after pv calculation

static bool end_flag = false; //indicates this is the last buffer
static long last_sample = 0; // last sample in file to play
static float *temp_buffer; //buffer for concatenating the tail of the latter buffer and the head of the former buffer

float *label_start_time;
float *label_stop_time;
long *label_index_beats;
long cur_beat_index = 0;
long cur_count = 0;
int update_check = 0;

long total_count = 0; //store the total number of sample that have been played
// long total_count_input = 0; //store the index of sample in input file refer to total_count

static long previous_input_count = 0; // used to compute hopsize in callback

int test_callback(long out_count, float *samples, int len, void *rock);

class LinearFunction {
public:
    float x_start;
    float y_start;
    float slope;
    LinearFunction(float x, float y, float new_slope){
        x_start = x;
        y_start = y;
        slope = new_slope;
    }
    void Set(float x, float y, float new_slope){
        x_start = x;
        y_start = y;
        slope = new_slope;
    }
};

float beatsToTime(float beats) {
    int i = 0;
    float time;
    while (label_index_beats[i] < beats) {
        i++;
    }
    if (label_index_beats[i] == beats) {
        time = label_start_time[i];
    } else {
        time = (label_start_time[i] - label_start_time[i - 1])
        * (beats - label_index_beats[i - 1])
        / (label_index_beats[i] - label_index_beats[i - 1])
        + label_start_time[i - 1];
    }
    return time; //add make sure there is beats 0, otherwise i-1 may not exist
    //add make sure label beats is round num
}

// --------- Audio Buffer
// Design:
//   double buffer. Two buffers are contiguous
//       initially load both with one read.
//   Reader: sets cur_buff to 0 or 1 to say which one we're reading.
//       Initially 0.
//       input_data is pointer to the next location from which to read
//       We have to figure out what to read and how much is available,
//       read the data, then update the pointer, so the access will be:
//           get_remainder() -- returns how many samples can be read
//           took(long n) -- say that we took n samples
//   Writer: sets next_buff to the number of the buffer that will
//       be written next. Initially 0, so we'll have to wait until
//       cur_buff is 1 to fill.
//           ready_for_more() -- returns pointer when a buffer is empty
//           write_completed() -- call after filling the buffer

class Audio_buffer {
    long samps_per_block;
    float *input_data;
    float *data;
    int cur_buff;
    int next_buff;
    int sample_count;
public:
    Audio_buffer(long read_block_bytes) {
        samps_per_block = read_block_bytes / sizeof(float);
        data = (float *) malloc(samps_per_block * 2 * sizeof(float));
        input_data = data;
        cur_buff = 0;
        next_buff = 0;
        sample_count = 0;
        assert(data);
    }
    
    ~Audio_buffer() {
        free(data);
    }
        
    long get_samps_per_block() { return samps_per_block; }
    
    float *get_read_ptr() { return input_data; }
    
    long get_sample_count() { return sample_count; }
    
    long get_remainder() { // how many samps can we read?
        float *end = data + (cur_buff + 1) * samps_per_block;
        return end - input_data;
    }
    
    void took(long n) {
        long remainder = get_remainder();
        if (remainder <= n) {
            cur_buff = 1 - cur_buff;
            input_data = data + cur_buff * samps_per_block;
            input_data -= remainder;
        }
        input_data += n;
        sample_count += n;
    }
    
    float *ready_for_more() {
        if (next_buff != cur_buff) {
            return data + next_buff * samps_per_block;
        }
        return NULL;
    }
    
    void write_completed() {
        next_buff = 1 - next_buff; // flip 0->1, 1->0
    }

    float *next_buffer() {
        return data + (1 - cur_buff) * samps_per_block;
    }

} buffer(READ_BLOCK);


typedef struct CallbackPara {
    Audio_buffer *buffer;
} PlayInfo;


static long output_count = 0;

static int playCallback(const void *inputBuffer, void *outputBuffer,
                        unsigned long framesPerBuffer,
                        const PaStreamCallbackTimeInfo *timeInfo,
                        PaStreamCallbackFlags statusFlags,
                        void *userData)
//portaudio callback function, details in portaudio documentation
{
    float *out = (float*)outputBuffer;
    (void) inputBuffer; //paCallback basic initialization
    
    //code here
    PlayInfo *info = (PlayInfo *)userData;
    Audio_buffer *buffer = info->buffer;
//#define PASSTHROUGH
//#define USE_ABSOLUTE
#ifdef PASSTHROUGH
    // ----- for debugging, just pass input to output ----
#ifdef USE_ABSOLUTE
    int hop = test_callback(output_count, out, BLOCK_SIZE, &previous_input_count);
    output_count += BLOCK_SIZE;
#else
    float *input_data = buffer->get_read_ptr();
    if (buffer->get_remainder() < BLOCK_SIZE) {
        long n = buffer->get_remainder();
        memcpy(temp_buffer, input_data, n * sizeof(float));
        buffer->took(n);
        memcpy(temp_buffer + n, buffer->get_read_ptr(),
               (BLOCK_SIZE - n) * sizeof(float));
        buffer->took(BLOCK_SIZE - n);
        memcpy(out, temp_buffer, BLOCK_SIZE * sizeof(float));
    } else {
        memcpy(out, input_data, BLOCK_SIZE * sizeof(float));
        buffer->took(BLOCK_SIZE);
    }
#endif // USE_ABSOLUTE
#else // no PASSTHROUGH
// if USE_ABSOLUTE is defined, we use the "absolute" interface to
// cmupv, which means cmupv calls a callback function with an 
// absolute output position to request exactly one input frame
// each time input data is required.
#ifdef USE_ABSOLUTE
    play_data = pv_get_output2(pv);
#else
    pv_set_ratio(pv, pv_ratio);
    int input_count = pv_get_input_count(pv);
    if (input_count < 0) {
        pv_end(pv);
        printf("Err: Inputcount is less than 0!\n");
        exit(1);
    } else {
        // even if input_count == 0 we need to pv_put_input()
        // to change the state to PV_GOT_INPUT:
        float *input_data = buffer->get_read_ptr();
        if (buffer->get_remainder() < input_count) {
            // not enough data left at end of buffer.
            // copy what we have to temp_buffer and
            // append data from the next buffer
            long n = buffer->get_remainder();
            memcpy(temp_buffer, input_data, n * sizeof(float));
            buffer->took(n);
            memcpy(temp_buffer + n, buffer->get_read_ptr(),
                   (input_count - n) * sizeof(float));
            buffer->took(input_count - n);
            pv_put_input(pv, input_count, temp_buffer);
        } else {
            // printf("pv_put_input %g\n", *input_data);
            pv_put_input(pv, input_count, input_data);
            buffer->took(input_count);
        }
    }
    // ---- run the phase vocoder! ----
    play_data = pv_get_output(pv);
    // printf("effective input %g, actual input %ld, output %ld\n",
    //       pv_get_effective_pos(pv), buffer->get_sample_count(),
    //       total_count + framesPerBuffer);
#endif // USE_ABSOLUTE
    memcpy(out, play_data, framesPerBuffer * sizeof(float));
    total_count += framesPerBuffer;
#endif
    if (buffer->get_sample_count() >= last_sample) {
        end_flag = true;
        return paComplete;
    }
    return paContinue;
}



// callback from cmupv: requests len input samples to be heard at
// out_count

int test_callback(long out_count, float *samples, int len, void *rock)
{
    // for this simple case, map out_count to in_count using a fixed rate
    long in_count = round(out_count * pv_ratio);
    in_count -= len / 2; // now in_count is sample where we get the *samples
    // in this test program, rock points to previous_input_count. It
    // should also point to the input buffer:
    long *prev = (long *) rock;
    int hopsize = in_count - *prev;
    *prev = in_count;
    buffer.took(hopsize); // advance to the desired input frame
    float *input_data = buffer.get_read_ptr();
    long n = buffer.get_remainder();
    printf("input_data %p, hop %ld, remainder %ld\n", input_data, hopsize, n);
    if (n < len) {
        memcpy(samples, input_data, n * sizeof(*samples));
        memcpy(samples + n, buffer.next_buffer(), (len - n) * sizeof(*samples));
    } else {
        memcpy(samples, input_data, len * sizeof(*samples));
    }
    return hopsize;
}


LinearFunction *cur_linear, *update_linear, *new_linear; //add need to reconstruct the .h file and declare they together
LinearFunction *gen_new_linear() {
    LinearFunction *new_linear = new LinearFunction(3,4,5);
    return new_linear;
}

void *WaitForUpdate(void *para){
    while(1){
        sleep(2);
        update_linear->slope = cur_linear->slope + (float)(random() % 100 - 50) / 100;
        update_linear->x_start = cur_linear->x_start + (float)(random() % 100 - 50) / 50;
        update_linear->y_start = cur_linear->y_start + (float)(random() % 100 - 50) / 50;
        update_check = (update_check + 1) % 10;
    }
}

int main (void)
{
    SNDFILE *infile;
    SF_INFO sfinfo ;
    const char *infilename = "audio/labeled-test.wav" ;
    long start_pos = 0;
    float start_time ;
    //outtt = (float *)malloc(sizeof(float) * READ_BLOCK * 5); //test
    
    PaStream *stream = 0;
    
    PaError err;
    err = Pa_Initialize();
    if (err != paNoError) {
        printf("Err : Pa_Initialize fail\n");
        printf("Error number: %d\n", err );
        printf("Error message: %s\n", Pa_GetErrorText(err));
        exit(1);
    }
    PlayInfo callback_parameter = { &buffer };
#ifdef USE_ABSOLUTE
    pv = pv_create2(malloc, free, test_callback, &previous_input_count);
#else
    pv = pv_create(malloc, free);
#endif
    // pv_set_blocksize(pv, BLOCK_SIZE);
    pv_set_fftsize(pv, 2048); // for testing
    // pv_set_syn_hopsize(pv, 32);
    pv_initialize(pv);
    
    if (!(infile = sf_open(infilename, SFM_READ, &sfinfo))) {
        printf ("Not able to open input file %s.\n", infilename) ;
        puts (sf_strerror (NULL)) ;
        return  1 ;
    }
    last_sample = sfinfo.frames; // this is where player stops
#define SHORT_SOUND_TEST
#ifdef SHORT_SOUND_TEST
    last_sample = 500000; // only play about 4s
#endif
    string line;
    size_t line_num;
    vector<string> label_track;
    ifstream label_file("audio/labeled-test.txt");
    if (label_file.is_open()) {
        while ( getline(label_file, line) ){
            label_track.push_back(line);
        }
    }
    line_num = label_track.size();
    label_start_time = new float[line_num];
    label_stop_time = new float[line_num];
    label_index_beats = new long[line_num];
    
    for (int i = 0 ; i < line_num; i++) {
        size_t first_delimiter_pos = 0, second_delimiter_pos = 0;        
        label_start_time[i] = stof(label_track[i].substr(), &first_delimiter_pos);
        label_stop_time[i] = stof(label_track[i].substr(first_delimiter_pos), &second_delimiter_pos);
        label_index_beats[i] = stol(label_track[i].substr(label_track[i].find_first_of("\"")+1
                                                         ,MAX_DIGIT_BEATS));
    }
    start_time = beatsToTime(5.5);
    cur_count = start_pos = (long)(start_time * sfinfo.samplerate);
    /* sf_seek(infile,(long)start_pos/sfinfo.channels,SEEK_SET); */

    if (sfinfo.channels > MAX_CHANNELS){
        printf ("Not able to process more than %d channels\n", MAX_CHANNELS);
        return 1;
    } //File open and checking
    
    long int read_per_time = READ_BLOCK / sizeof(float);
    
    // TODO: this is REALLY big for temp_buffer. Should be able to find an upper bound
    temp_buffer = (float *) malloc(sizeof(float) * read_per_time);
    
    // ------- Preload the Buffers ------
    float *buf = buffer.get_read_ptr();
    readcount = sf_read_float(infile, buf, read_per_time * 2);
    if (readcount != read_per_time * 2) {
        printf("Err: Could not preload buffers!\n");
        sf_close (infile) ;
        return 0;
    }
    printf("read %ld samples, buf[100000] %g\n", readcount, buf[100000]);
    // ------- Open Audio Stream --------
    
    err = Pa_OpenDefaultStream(&stream, 0, 1, paFloat32, sfinfo.samplerate,
                               BLOCK_SIZE, playCallback, (void *)&callback_parameter);
    if (err != paNoError) {
        printf("Err: cannot open Pa_stream!\n");
        printf("Error number: %d\n", err );
        printf("Error message: %s\n", Pa_GetErrorText( err ) );
        exit(1);
    }
        
    //printf("3\n");
        
    err = Pa_StartStream(stream);
    if (err != paNoError) {
        err = Pa_StopStream(stream);
        err = Pa_CloseStream(stream);
        
        printf("Err : Pa_StartStream Fail!\n");
        printf("Error number: %d\n", err);
        printf("Error message: %s\n", Pa_GetErrorText(err));
        exit(1);
    }
    
    // ------- Fill Buffers While Audio Stream Runs ---------
    bool audio_file_has_data = true;
    while (!end_flag) {
        // fill the buffer if there is space
        float *buff = buffer.ready_for_more();
        if (buff && audio_file_has_data) {
            cout << "reading more audio data" << endl;
            readcount = sf_read_float(infile, buff, read_per_time);
            if (readcount != read_per_time) {
                audio_file_has_data = false;
                cout << "reading finished with readcount " << readcount << endl;
            }
            buffer.write_completed();
        }        
        // wait a bit to avoid hogging the CPU
        usleep(10000);
    }        
    // add should consider some extreme situation
    // add make sure sf_read_float returns the actual amount samples read

    err = Pa_StopStream( stream );
    if( err != paNoError ){
        printf("Pa_StopStreamError!\n");
        printf("Error number: %d\n", err );
        printf("Error message: %s\n", Pa_GetErrorText( err ) );
        exit(1);
    }
    err = Pa_CloseStream( stream );
    if( err != paNoError ){
        printf("Pa_CloseStream Fail!\n");
        printf("Error number: %d\n", err );
        printf("Error message: %s\n", Pa_GetErrorText( err ) );
        exit(1);
    }
    pv_end(pv);
    Pa_Terminate();
    sf_close(infile);
    
    free(temp_buffer);
    printf("Project Finished!\n");
    // finalize

    delete[] label_start_time;
    delete[] label_stop_time;
    delete[] label_index_beats;

    return 0;
}

//final two threads
