//
//  Network.cpp
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//
#include "audio_player.h"

extern Network network;
extern MainFrame *main_frame;

NetworkDialog::NetworkDialog()
: wxDialog(NULL, -1, "Network Configuration", wxDefaultPosition, wxSize(500,100)){
    wxPanel *pan = new wxPanel(this, wxID_ANY);
    
    wxStaticText *label_host_ip = new wxStaticText(pan, wxID_ANY, "Host IP:");
    wxtxt_host_ip = new wxTextCtrl(pan, wxID_ANY, "localhost", wxDefaultPosition, wxSize(120,-1));
    
    wxButton *connect = new wxButton(pan, ID_DIALOG_NETWORK_CONNECT, "Connect");
    wxButton *cancel = new wxButton(pan, ID_DIALOG_NETWORK_CANCEL, "Cancel");
    
    wxBoxSizer *first_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *second_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *whole_sizer = new wxBoxSizer(wxVERTICAL);
    
    first_line->Add(label_host_ip, wxSizerFlags(0).Align(1).Border(wxALL,5));
    first_line->Add(wxtxt_host_ip, wxSizerFlags(0).Align(1).Border(wxALL,5));
    second_line->Add(connect, wxSizerFlags(0).Align(1).Border(wxALL,5));
    second_line->Add(cancel, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(first_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(second_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    pan->SetSizer(whole_sizer);
    
    SetEscapeId(ID_DIALOG_NETWORK_CANCEL);
    Connect(ID_DIALOG_NETWORK_CONNECT, wxEVT_COMMAND_BUTTON_CLICKED
            , wxCommandEventHandler(NetworkDialog::OnConnect));
    
}
NetworkDialog::~NetworkDialog(){
    Destroy();
}

void NetworkDialog :: OnConnect(wxCommandEvent & WXUNUSED(event)) {
    std::string ipstr = wxtxt_host_ip->GetValue().ToStdString();
    try {
        if (!ipstr.empty()) {
            network.Connect(ipstr, "5566", "5544");
        } else {
            network.Connect("localhost", "5566", "5544");
        }
        network.Join();
    } catch (zmq::error_t &error) {
        wxMessageDialog err(NULL, wxString::Format("Error: %s",error.what()), "Err", wxOK);
        err.ShowModal();
        return ;
    }
    if (ipstr.empty()) {
        EndModal(HOSTIP_NONE);
    } else if (ipstr.compare("localhost") == 0) {
        EndModal(HOSTIP_LOCALHOST);
    }
}