//
//  Network.h
//  AudioPlayer
//
//  Created by Joe on 6/23/15.
//  Copyright (c) 2015 Joe. All rights reserved.
//

#ifndef __AudioPlayer__Network__
#define __AudioPlayer__Network__


#include "wx/wx.h"
//set network connection dialog class
//************Description***************
//this is a new dialog about connect to the destination
//***************************
class NetworkDialog : public wxDialog{
    wxTextCtrl *wxtxt_host_ip;
public:
    NetworkDialog();
    void OnConnect(wxCommandEvent &event);
    ~NetworkDialog();
};

#endif /* defined(__AudioPlayer__Network__) */
