//
//  mediamap.h
//  audioplayer
//
//  Created by Joe on 7/6/15.
//
//

#ifndef __audioplayer__mediamap__
#define __audioplayer__mediamap__

#include "wx/wx.h"
#include <string>

class MediaMap : public wxDialog{
    wxTextCtrl *mapping_text;
    wxButton *button_ok;
    wxButton *button_cancel;
    
    void OnConfirm (wxCommandEvent &event);
public:
    MediaMap();
    ~MediaMap();
    void InitRead(std::string file_name);
};


#endif /* defined(__audioplayer__mediamap__) */
