//
//  mediamap.cpp
//  audioplayer
//
//  Created by Joe on 7/6/15.
//
//

#include "audio_player.h"
#include "wx/file.h"

extern PrjPara prjpara;
extern GlbPara glbpara;

MediaMap::MediaMap()
: wxDialog(NULL, wxID_ANY, "Media Mapping", wxDefaultPosition, wxSize(330,400)) {
    wxPanel *pan = new wxPanel(this, wxID_ANY);
    mapping_text = new wxTextCtrl(pan, wxID_ANY, "", wxDefaultPosition,
                                  wxSize(240,300), wxTE_MULTILINE);
    button_cancel = new wxButton(pan, ID_DIALOG_MEDIA_MAPPING_CANCEL, "Cancel");
    button_ok = new wxButton(pan, ID_DIALOG_MEDIA_MAPPING_OK, "Confirm");
    
    wxBoxSizer *first_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *second_line = new wxBoxSizer(wxHORIZONTAL);
    wxBoxSizer *whole_sizer = new wxBoxSizer(wxVERTICAL);
    first_line->Add(mapping_text, wxSizerFlags(0).Align(1).Border(wxALL,5));
    second_line->Add(button_ok, wxSizerFlags(0).Align(1).Border(wxALL,5));
    second_line->Add(button_cancel, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(first_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    whole_sizer->Add(second_line, wxSizerFlags(0).Align(1).Border(wxALL, 5));
    pan->SetSizer(whole_sizer);
    
    SetEscapeId(ID_DIALOG_MEDIA_MAPPING_CANCEL);
    Connect(ID_DIALOG_MEDIA_MAPPING_OK, wxEVT_COMMAND_BUTTON_CLICKED,
            wxCommandEventHandler(MediaMap::OnConfirm));
    InitRead(prjpara.rmm_file);
}

MediaMap::~MediaMap() {
    Destroy();
}

void MediaMap::OnConfirm(wxCommandEvent & WXUNUSED(event)) {
    wxString text = mapping_text->GetValue();
    prjpara.rmm_file = (std::string)(glbpara.music_path) + "/" + glbpara.prj_name
                + "/" + glbpara.aud_name + "/" + "mediamapping.txt";
    if (text.IsEmpty()) {
        std::remove(prjpara.rmm_file.c_str());
        EndModal(SUCCESSFUL);
        return ;
    } else {
        wxFile fmapping(prjpara.rmm_file.c_str(), wxFile::write);
        if (fmapping.IsOpened()) {
            fmapping.Write(text);
            EndModal(SUCCESSFUL);
        } else {
            wxMessageDialog err(NULL, "Cannot Open mediamapping.txt","Error", wxOK);
            err.ShowModal();
        }
        fmapping.Close();
        return ;
    }
}

void MediaMap::InitRead(std::string file_name) {
    if (getPathStatus(&file_name) == APPATH_FILE) {
        wxString text;
        wxFile fread(file_name.c_str(), wxFile::read);
        if (fread.IsOpened()) {
            fread.ReadAll(&text);
            mapping_text->SetValue(text);
        } else {
            wxMessageDialog err(NULL, "Cannot Open mediamapping.txt","Error", wxOK);
            err.ShowModal();
        }
        fread.Close();
    }
    return ;
}