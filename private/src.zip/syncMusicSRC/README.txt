Due to the face that this is a personal project, I cannot show you the whole project, just part of my code here.

Contact me if you have any questions.